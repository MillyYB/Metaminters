import { storage } from "./storage";
import type { InsertUser, InsertNFT, InsertCollection, InsertActivity } from "@shared/schema";
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

const scryptAsync = promisify(scrypt);

// Function to hash passwords
async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

// NFT collection names
const collectionNames = [
  "Ethereal Dreams",
  "Crimson Legacy",
  "Digital Shadows",
  "Neon Dystopia",
  "Quantum Realms",
  "Dark Matter",
  "Cosmic Visions",
  "Ruby Genesis"
];

// User names and details
const userDetailsBase = [
  { firstName: "Alex", lastName: "Morgan", username: "cryptoalex" },
  { firstName: "Sophia", lastName: "Chen", username: "sophianft" },
  { firstName: "Marcus", lastName: "Johnson", username: "mjcollector" },
  { firstName: "Elena", lastName: "Rodriguez", username: "elenacrypto" },
  { firstName: "David", lastName: "Kim", username: "davidkim" },
  { firstName: "Olivia", lastName: "Smith", username: "olivianft" },
  { firstName: "Jason", lastName: "Taylor", username: "jasont" },
  { firstName: "Mia", lastName: "Williams", username: "miaw" },
  { firstName: "Ryan", lastName: "Brown", username: "ryanbrown" },
  { firstName: "Zoe", lastName: "Davis", username: "zoedavis" },
  { firstName: "Emiliana", lastName: "Rokash", username: "erokash", isAdmin: true }
];

// NFT names and descriptions
const nftDetails = [
  { name: "Crimson Cosmos #1", description: "A vivid portrayal of a cosmic scene with red nebulas and distant stars" },
  { name: "Digital Soul #24", description: "An AI interpretation of human consciousness in the digital realm" },
  { name: "Neon City Nights", description: "A futuristic cityscape illuminated by vibrant neon lights" },
  { name: "Abstract Thoughts #7", description: "A visualization of complex thought patterns in abstract form" },
  { name: "Quantum Entanglement", description: "Two interconnected particles defying the laws of physics" },
  { name: "Ethereal Forest", description: "A mystical forest glowing with supernatural energy" },
  { name: "Cybernetic Dreams", description: "The fusion of human imagination and machine precision" },
  { name: "Midnight Serenade", description: "Dark, melodic patterns inspired by nocturnal soundscapes" },
  { name: "Solar Flare Nexus", description: "Dynamic energy bursts captured from a distant star" },
  { name: "Geometric Harmony", description: "Perfect mathematical structures forming a harmonious composition" },
  { name: "Digital Genesis #13", description: "The birth of a new digital universe with infinite possibilities" },
  { name: "Temporal Distortion", description: "A visualization of time bending and warping around itself" },
  { name: "Neural Pathway", description: "The complex connections within an artificial neural network" },
  { name: "Void Echoes", description: "Enigmatic signals emanating from the dark void of space" },
  { name: "Ruby Reflection", description: "Deep crimson patterns reflecting and refracting light" },
  { name: "Binary Cascade", description: "A waterfall of binary data flowing into complex structures" },
  { name: "Plasma Dreams", description: "Swirling patterns of energized plasma forming abstract shapes" },
  { name: "Fractal Dimension", description: "Infinite recursive patterns that maintain self-similarity" },
  { name: "Celestial Cartography", description: "A map of an unexplored celestial region" },
  { name: "Spectral Analysis #9", description: "Visual representation of sound frequencies in spectral form" }
];

// Sample image URLs for NFTs - abstract digital art
const sampleImageUrls = [
  "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe",
  "https://images.unsplash.com/photo-1558591710-4b4a1ae0f04d",
  "https://images.unsplash.com/photo-1579546929662-711aa81148cf",
  "https://images.unsplash.com/photo-1567095761054-7a02e69e5c43",
  "https://images.unsplash.com/photo-1550859492-d5da9d8e45f3",
  "https://images.unsplash.com/photo-1563089145-599997674d42",
  "https://images.unsplash.com/photo-1518640467707-6811f4a6ab73",
  "https://images.unsplash.com/photo-1506792006437-256b665541e2",
  "https://images.unsplash.com/photo-1575909812264-6deb47291a1c",
  "https://images.unsplash.com/photo-1520034475321-cbe63696469a"
];

// Wallet addresses for users
const walletAddresses = [
  "0x1234567890123456789012345678901234567890",
  "0x2345678901234567890123456789012345678901",
  "0x3456789012345678901234567890123456789012",
  "0x4567890123456789012345678901234567890123",
  "0x5678901234567890123456789012345678901234",
  "0x6789012345678901234567890123456789012345",
  "0x7890123456789012345678901234567890123456",
  "0x8901234567890123456789012345678901234567",
  "0x9012345678901234567890123456789012345678",
  "0x0123456789012345678901234567890123456789",
  "0x7890123456789012345678901234567890123456" // Admin wallet
];

// Action types for activity
const actionTypes = ["mint", "purchase", "list", "transfer", "offer", "like"];

// Function to generate a random element from an array
function getRandomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

// Function to generate a random date in the last year
function getRandomDate(startDaysAgo = 365, endDaysAgo = 0): Date {
  const start = new Date();
  start.setDate(start.getDate() - startDaysAgo);
  
  const end = new Date();
  end.setDate(end.getDate() - endDaysAgo);
  
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

// Main seed function
export async function seedDatabase() {
  console.log("Starting database seeding...");
  
  // 1. Check if we already have users beyond the admin
  const existingUsers = await storage.listUsers();
  if (existingUsers.length > 2) {
    console.log("Database already seems to be seeded. Skipping seeding process.");
    return;
  }
  
  // 2. Create user accounts
  const createdUsers = [];
  
  for (let i = 0; i < userDetailsBase.length; i++) {
    const details = userDetailsBase[i];
    const email = `${details.username}@example.com`;
    
    // Skip if user already exists
    const existingUser = await storage.getUserByEmail(email);
    if (existingUser) {
      createdUsers.push(existingUser);
      continue;
    }
    
    const user: InsertUser = {
      username: details.username,
      firstName: details.firstName,
      lastName: details.lastName,
      email: email,
      password: await hashPassword("Password123!"),
      walletAddress: walletAddresses[i],
      isVerified: true,
      isAdmin: !!details.isAdmin,
      bio: `NFT enthusiast and collector. Passionate about digital art and blockchain technology.`,
      confirmPassword: "Password123!"
    };
    
    const createdUser = await storage.createUser(user);
    createdUsers.push(createdUser);
    console.log(`Created user: ${createdUser.username}`);
  }
  
  // 3. Create collections
  const createdCollections = [];
  
  for (const name of collectionNames) {
    const randomUser = getRandomElement(createdUsers);
    
    const collection: InsertCollection = {
      name,
      description: `A unique collection of digital art exploring ${name.toLowerCase()} themes.`,
      ownerId: randomUser.id
    };
    
    const createdCollection = await storage.createCollection(collection);
    createdCollections.push(createdCollection);
    console.log(`Created collection: ${createdCollection.name}`);
  }
  
  // 4. Create NFTs and activities
  const createdNfts = [];
  
  // Create approximately 70 NFTs
  for (let i = 0; i < 70; i++) {
    // Pick a random NFT details and modify it slightly to create variations
    const baseDetails = getRandomElement(nftDetails);
    const id = Math.floor(Math.random() * 999) + 1;
    const name = baseDetails.name.includes("#") 
      ? baseDetails.name.split("#")[0] + `#${id}`
      : `${baseDetails.name} #${id}`;
    
    const randomUser = getRandomElement(createdUsers);
    const randomCollection = getRandomElement(createdCollections);
    
    const nft: InsertNFT = {
      name,
      description: baseDetails.description,
      imageUrl: getRandomElement(sampleImageUrls) + `?random=${i}`,
      ownerId: randomUser.id,
      collection: randomCollection.name,
      price: "0.52" // Fixed price as per requirements
    };
    
    const createdNft = await storage.createNft(nft);
    createdNfts.push(createdNft);
    console.log(`Created NFT: ${createdNft.name}`);
    
    // Add 2-5 activities for each NFT
    const numActivities = Math.floor(Math.random() * 4) + 2;
    
    for (let j = 0; j < numActivities; j++) {
      // For the first activity, it should always be a mint by the owner
      if (j === 0) {
        // Mint activity is already created by the storage.createNft method
        continue;
      }
      
      // For subsequent activities, pick a random activity type and user
      const action = getRandomElement(actionTypes.filter(a => a !== "mint")); // Can't mint twice
      const activityUser = j === 1 ? getRandomElement(createdUsers.filter(u => u.id !== randomUser.id)) : getRandomElement(createdUsers);
      
      let details = "";
      switch (action) {
        case "purchase":
          details = `Purchased "${createdNft.name}" for 0.52 ETH`;
          break;
        case "list":
          details = `Listed "${createdNft.name}" for sale at 0.52 ETH`;
          break;
        case "transfer":
          details = `Transferred "${createdNft.name}" to ${getRandomElement(createdUsers).username}`;
          break;
        case "offer":
          details = `Made an offer of 0.5 ETH for "${createdNft.name}"`;
          break;
        case "like":
          details = `Liked "${createdNft.name}"`;
          break;
      }
      
      const activity: InsertActivity = {
        userId: activityUser.id,
        nftId: createdNft.id,
        action,
        details
      };
      
      await storage.createActivity(activity);
    }
  }
  
  console.log("Database seeding completed successfully!");
  console.log(`Created ${createdUsers.length} users, ${createdCollections.length} collections, and ${createdNfts.length} NFTs.`);
}