import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import * as schema from '@shared/schema';

// Database connection string from environment variables
const connectionString = process.env.DATABASE_URL || '';

// Check if the connection string is set
if (!connectionString) {
  throw new Error('DATABASE_URL environment variable is not set');
}

// Database client for queries
const queryClient = postgres(connectionString);

// Create the Drizzle ORM instance
export const db = drizzle(queryClient, { schema });

// Run migrations - we'll call this function in the server startup
// Instead of running file-based migrations, we'll use the drizzle-kit push approach
export async function runMigrations() {
  try {
    console.log('Database setup complete');
    return Promise.resolve();
  } catch (error) {
    console.error('Error setting up database:', error);
    throw error;
  }
}