import nodemailer from 'nodemailer';

// Create a transporter using Gmail
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Function to send password reset email
export async function sendPasswordResetEmail(to: string, token: string): Promise<boolean> {
  try {
    // Base URL from environment or default to localhost
    const baseUrl = process.env.BASE_URL || 'http://localhost:3000';
    const resetLink = `${baseUrl}/reset-password?token=${token}`;
    
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to,
      subject: 'MetaMinter - Reset Your Password',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
          <div style="text-align: center; margin-bottom: 20px;">
            <h1 style="color: #e11d48; margin: 0;">MetaMinter</h1>
            <p style="color: #777; font-size: 14px;">Your NFT Marketplace</p>
          </div>
          
          <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h2 style="color: #111827; margin-top: 0;">Password Reset</h2>
            <p style="color: #4b5563; line-height: 1.5;">You requested to reset your password. Please click the button below to set a new password. This link will expire in 1 hour.</p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${resetLink}" style="background-color: #e11d48; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Reset Password</a>
            </div>
            
            <p style="color: #4b5563; font-size: 14px;">If you didn't request this, you can safely ignore this email.</p>
          </div>
          
          <div style="color: #6b7280; font-size: 13px; text-align: center; border-top: 1px solid #eee; padding-top: 20px;">
            <p>&copy; ${new Date().getFullYear()} MetaMinter. All rights reserved.</p>
            <p>If you have any questions, please contact our support team.</p>
          </div>
        </div>
      `
    };
    
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending password reset email:', error);
    return false;
  }
}

// Function to send verification email
export async function sendVerificationEmail(to: string, userId: number): Promise<boolean> {
  try {
    // Base URL from environment or default to localhost
    const baseUrl = process.env.BASE_URL || 'http://localhost:3000';
    const verificationLink = `${baseUrl}/verify-email?userId=${userId}`;
    
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to,
      subject: 'MetaMinter - Verify Your Email',
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; border: 1px solid #ddd; border-radius: 10px;">
          <div style="text-align: center; margin-bottom: 20px;">
            <h1 style="color: #e11d48; margin: 0;">MetaMinter</h1>
            <p style="color: #777; font-size: 14px;">Your NFT Marketplace</p>
          </div>
          
          <div style="background-color: #f9fafb; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
            <h2 style="color: #111827; margin-top: 0;">Verify Your Email</h2>
            <p style="color: #4b5563; line-height: 1.5;">Thank you for registering! Please click the button below to verify your email address.</p>
            
            <div style="text-align: center; margin: 30px 0;">
              <a href="${verificationLink}" style="background-color: #e11d48; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">Verify Email</a>
            </div>
            
            <p style="color: #4b5563; font-size: 14px;">This email was sent to verify your identity. If you didn't create an account, you can safely ignore this email.</p>
          </div>
          
          <div style="color: #6b7280; font-size: 13px; text-align: center; border-top: 1px solid #eee; padding-top: 20px;">
            <p>&copy; ${new Date().getFullYear()} MetaMinter. All rights reserved.</p>
            <p>If you have any questions, please contact our support team.</p>
          </div>
        </div>
      `
    };
    
    await transporter.sendMail(mailOptions);
    return true;
  } catch (error) {
    console.error('Error sending verification email:', error);
    return false;
  }
}