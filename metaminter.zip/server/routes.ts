import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  loginUserSchema, 
  insertNftSchema, 
  insertCollectionSchema,
  forgotPasswordSchema,
  resetPasswordSchema
} from "@shared/schema";
import session from "express-session";
import memorystore from "memorystore";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { sendPasswordResetEmail } from "./email";

declare module "express-session" {
  interface SessionData {
    userId: number;
    isAuthenticated: boolean;
    isAdmin: boolean;
  }
}

const MemoryStore = memorystore(session);

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "nft-minting-app-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        maxAge: 24 * 60 * 60 * 1000, // 24 hours
      },
      store: new MemoryStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
    })
  );

  // Middleware to check auth status
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.isAuthenticated) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    next();
  };

  // Middleware to check admin status
  const requireAdmin = (req: Request, res: Response, next: Function) => {
    if (!req.session.isAuthenticated || !req.session.isAdmin) {
      return res.status(403).json({ message: "Forbidden" });
    }
    next();
  };

  // Middleware to check verification status
  const requireVerified = async (req: Request, res: Response, next: Function) => {
    if (!req.session.isAuthenticated) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    const user = await storage.getUser(req.session.userId!);
    if (!user || !user.isVerified) {
      return res.status(403).json({ message: "Account pending verification" });
    }
    
    next();
  };

  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUserByEmail = await storage.getUserByEmail(userData.email);
      if (existingUserByEmail) {
        return res.status(409).json({ message: "Email already registered" });
      }
      
      const existingUserByUsername = await storage.getUserByUsername(userData.username);
      if (existingUserByUsername) {
        return res.status(409).json({ message: "Username already taken" });
      }
      
      // Create user (the storage.createUser method will handle removing confirmPassword)
      const user = await storage.createUser(userData);
      
      return res.status(201).json({
        id: user.id,
        username: user.username,
        email: user.email,
        isVerified: user.isVerified,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Register error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = loginUserSchema.parse(req.body);
      
      const user = await storage.getUserByEmail(loginData.email);
      if (!user || user.password !== loginData.password) {
        return res.status(401).json({ message: "Invalid email or password" });
      }
      
      // Set session data
      req.session.userId = user.id;
      req.session.isAuthenticated = true;
      req.session.isAdmin = user.isAdmin || false;
      
      return res.status(200).json({
        id: user.id,
        username: user.username,
        email: user.email,
        isVerified: user.isVerified,
        isAdmin: user.isAdmin,
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Login error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      return res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.isAuthenticated) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.session.userId!);
    if (!user) {
      req.session.destroy(() => {});
      return res.status(404).json({ message: "User not found" });
    }
    
    return res.status(200).json({
      id: user.id,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      bio: user.bio,
      walletAddress: user.walletAddress,
      isVerified: user.isVerified,
      isAdmin: user.isAdmin,
    });
  });

  // User routes
  app.get("/api/users/pending", requireAdmin, async (req, res) => {
    const pendingUsers = await storage.listPendingUsers();
    return res.status(200).json(pendingUsers.map(user => ({
      id: user.id,
      username: user.username,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      walletAddress: user.walletAddress,
      registeredAt: user.registeredAt,
    })));
  });

  app.put("/api/users/:id/verify", requireAdmin, async (req, res) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }
    
    const updatedUser = await storage.verifyUser(userId);
    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }
    
    return res.status(200).json({
      id: updatedUser.id,
      username: updatedUser.username,
      isVerified: updatedUser.isVerified,
    });
  });

  app.put("/api/users/profile", requireAuth, async (req, res) => {
    try {
      const updates = req.body;
      
      // Don't allow updating sensitive fields
      const { password, isAdmin, isVerified, ...allowedUpdates } = updates;
      
      const updatedUser = await storage.updateUser(req.session.userId!, allowedUpdates);
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      return res.status(200).json({
        id: updatedUser.id,
        username: updatedUser.username,
        firstName: updatedUser.firstName,
        lastName: updatedUser.lastName,
        email: updatedUser.email,
        bio: updatedUser.bio,
        walletAddress: updatedUser.walletAddress,
      });
    } catch (error) {
      console.error("Update profile error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // NFT routes
  app.post("/api/nfts", requireVerified, async (req, res) => {
    try {
      const nftData = insertNftSchema.parse({
        ...req.body,
        ownerId: req.session.userId,
      });
      
      const nft = await storage.createNft(nftData);
      
      return res.status(201).json(nft);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Create NFT error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/nfts", async (req, res) => {
    const nfts = await storage.getAllNfts();
    return res.status(200).json(nfts);
  });

  app.get("/api/nfts/user", requireAuth, async (req, res) => {
    const nfts = await storage.getUserNfts(req.session.userId!);
    return res.status(200).json(nfts);
  });
  
  // NFT Transfer Endpoint - Used when purchasing an NFT
  app.post("/api/nfts/:id/transfer", requireAuth, async (req, res) => {
    try {
      const nftId = parseInt(req.params.id);
      if (isNaN(nftId)) {
        return res.status(400).json({ message: "Invalid NFT ID" });
      }
      
      // Get the NFT to verify it exists
      const nft = await storage.getNft(nftId);
      if (!nft) {
        return res.status(404).json({ message: "NFT not found" });
      }
      
      // Buyer is the current user
      const buyerId = req.session.userId!;
      
      // Create activity record for the purchase
      // This is in addition to the activity created on the client
      // to ensure we have a record even if the client-side fails
      await storage.createActivity({
        userId: buyerId,
        nftId,
        type: "purchase",
        description: `Purchased NFT #${nftId} for ${nft.price || '0.52'} ETH`,
        transactionHash: req.body.transactionHash || null,
      });
      
      // Update NFT ownership with sale information
      const updatedNft = await storage.updateNft(nftId, {
        ownerId: buyerId
      });
      
      if (!updatedNft) {
        return res.status(500).json({ message: "Failed to update NFT ownership" });
      }
      
      return res.status(200).json(updatedNft);
    } catch (error) {
      console.error("NFT transfer error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  // Collections routes
  app.post("/api/collections", requireVerified, async (req, res) => {
    try {
      const collectionData = insertCollectionSchema.parse({
        ...req.body,
        ownerId: req.session.userId,
      });
      
      const collection = await storage.createCollection(collectionData);
      
      return res.status(201).json(collection);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error("Create collection error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/collections", async (req, res) => {
    const collections = await storage.getAllCollections();
    return res.status(200).json(collections);
  });

  // Activity routes
  app.get("/api/activity", requireAuth, async (req, res) => {
    const activities = await storage.getUserActivity(req.session.userId!);
    
    // Hydrate activities with related entities
    const hydratedActivities = await Promise.all(
      activities.map(async (activity) => {
        let nft = undefined;
        if (activity.nftId) {
          nft = await storage.getNft(activity.nftId);
        }
        
        return {
          ...activity,
          nft: nft ? {
            id: nft.id,
            name: nft.name,
            imageUrl: nft.imageUrl,
          } : undefined,
        };
      })
    );
    
    return res.status(200).json(hydratedActivities);
  });
  
  // Password reset routes
  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = forgotPasswordSchema.parse(req.body);
      
      // Check if user exists
      const user = await storage.getUserByEmail(email);
      if (!user) {
        // Don't reveal if email exists or not for security
        return res.status(200).json({ 
          message: "If your email is registered, you will receive a password reset link" 
        });
      }
      
      // Create password reset token
      const token = await storage.createPasswordResetToken(email);
      if (!token) {
        return res.status(500).json({ message: "Failed to create reset token" });
      }
      
      // Send password reset email
      const emailSent = await sendPasswordResetEmail(email, token);
      if (!emailSent) {
        return res.status(500).json({ message: "Failed to send reset email" });
      }
      
      return res.status(200).json({ 
        message: "If your email is registered, you will receive a password reset link" 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Forgot password error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  app.post("/api/auth/reset-password", async (req, res) => {
    try {
      const { token, password } = resetPasswordSchema.parse(req.body);
      
      // Reset the password
      const success = await storage.resetPassword(token, password);
      if (!success) {
        return res.status(400).json({ 
          message: "Invalid or expired reset token" 
        });
      }
      
      return res.status(200).json({ 
        message: "Password reset successful. You can now log in with your new password." 
      });
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      
      console.error("Reset password error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });
  
  // Create activity record - used from client when minting or purchasing
  app.post("/api/activity", requireAuth, async (req, res) => {
    try {
      const { type, nftId, description, transactionHash } = req.body;
      
      // Require at least a type
      if (!type) {
        return res.status(400).json({ message: "Activity type is required" });
      }
      
      const activity = await storage.createActivity({
        userId: req.session.userId!,
        type,
        nftId: nftId || null,
        description: description || null,
        transactionHash: transactionHash || null,
      });
      
      return res.status(201).json(activity);
    } catch (error) {
      console.error("Create activity error:", error);
      return res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
