import { 
  users, 
  nfts, 
  collections, 
  activity, 
  type User, 
  type NFT, 
  type Collection,
  type Activity,
  type InsertUser,
  type InsertNFT,
  type InsertCollection,
  type InsertActivity 
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByResetToken(token: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  verifyUser(id: number): Promise<User | undefined>;
  createPasswordResetToken(email: string): Promise<string | null>;
  resetPassword(token: string, newPassword: string): Promise<boolean>;
  listUsers(): Promise<User[]>;
  listPendingUsers(): Promise<User[]>;
  
  // NFT operations
  getNft(id: number): Promise<NFT | undefined>;
  createNft(nft: InsertNFT): Promise<NFT>;
  updateNft(id: number, updates: Partial<NFT>): Promise<NFT | undefined>;
  getUserNfts(userId: number): Promise<NFT[]>;
  getAllNfts(): Promise<NFT[]>;
  
  // Collection operations
  getCollection(id: number): Promise<Collection | undefined>;
  createCollection(collection: InsertCollection): Promise<Collection>;
  getUserCollections(userId: number): Promise<Collection[]>;
  getAllCollections(): Promise<Collection[]>;
  
  // Activity operations
  createActivity(activity: InsertActivity): Promise<Activity>;
  getUserActivity(userId: number): Promise<Activity[]>;
}

// The DatabaseStorage implementation to replace MemStorage
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result.length > 0 ? result[0] : undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select()
      .from(users)
      .where(eq(users.username, username));
    return result.length > 0 ? result[0] : undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const result = await db.select()
      .from(users)
      .where(eq(users.email, email));
    return result.length > 0 ? result[0] : undefined;
  }

  async getUserByResetToken(token: string): Promise<User | undefined> {
    const result = await db.select()
      .from(users)
      .where(eq(users.resetToken, token));
    
    if (result.length === 0) return undefined;
    
    const user = result[0];
    
    // Check if token is expired
    if (user.resetTokenExpiry && new Date(user.resetTokenExpiry) < new Date()) {
      // Token is expired, clear it
      await this.updateUser(user.id, { 
        resetToken: null, 
        resetTokenExpiry: null 
      });
      return undefined;
    }
    
    return user;
  }

  async createUser(userData: InsertUser): Promise<User> {
    // Remove confirmPassword which isn't part of our database schema
    const { confirmPassword, ...userDataWithoutConfirm } = userData;
    
    const result = await db.insert(users)
      .values(userDataWithoutConfirm)
      .returning();
    
    return result[0];
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const result = await db.update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }

  async verifyUser(id: number): Promise<User | undefined> {
    return this.updateUser(id, { isVerified: true });
  }
  
  async createPasswordResetToken(email: string): Promise<string | null> {
    const user = await this.getUserByEmail(email);
    if (!user) return null;
    
    // Generate a random token
    const token = Math.random().toString(36).substring(2, 15) + 
                 Math.random().toString(36).substring(2, 15);
                 
    // Token expires in 1 hour
    const expiry = new Date();
    expiry.setHours(expiry.getHours() + 1);
    
    // Update user with the reset token
    await this.updateUser(user.id, {
      resetToken: token,
      resetTokenExpiry: expiry
    });
    
    return token;
  }
  
  async resetPassword(token: string, newPassword: string): Promise<boolean> {
    const user = await this.getUserByResetToken(token);
    if (!user) return false;
    
    // Update the user's password and clear the token
    await this.updateUser(user.id, {
      password: newPassword,
      resetToken: null,
      resetTokenExpiry: null
    });
    
    return true;
  }

  async listUsers(): Promise<User[]> {
    return db.select().from(users);
  }

  async listPendingUsers(): Promise<User[]> {
    return db.select()
      .from(users)
      .where(
        and(
          eq(users.isVerified, false),
          eq(users.isAdmin, false)
        )
      );
  }

  // NFT operations
  async getNft(id: number): Promise<NFT | undefined> {
    const result = await db.select()
      .from(nfts)
      .where(eq(nfts.id, id));
    
    return result.length > 0 ? result[0] : undefined;
  }

  async createNft(nftData: InsertNFT): Promise<NFT> {
    // Generate a token ID for the NFT
    const tokenId = `NFT-${Date.now().toString(36)}-${Math.random().toString(36).substr(2, 5)}`;
    
    const result = await db.insert(nfts)
      .values({
        ...nftData,
        tokenId,
      })
      .returning();
    
    const newNft = result[0];
    
    // Create an activity for the minting
    await this.createActivity({
      userId: newNft.ownerId,
      nftId: newNft.id,
      type: 'mint',
      description: `Minted NFT "${newNft.name}"`
    });
    
    return newNft;
  }

  async getUserNfts(userId: number): Promise<NFT[]> {
    return db.select()
      .from(nfts)
      .where(eq(nfts.ownerId, userId));
  }

  async updateNft(id: number, updates: Partial<NFT>): Promise<NFT | undefined> {
    const result = await db.update(nfts)
      .set(updates)
      .where(eq(nfts.id, id))
      .returning();
    
    return result.length > 0 ? result[0] : undefined;
  }

  async getAllNfts(): Promise<NFT[]> {
    return db.select().from(nfts);
  }

  // Collection operations
  async getCollection(id: number): Promise<Collection | undefined> {
    const result = await db.select()
      .from(collections)
      .where(eq(collections.id, id));
    
    return result.length > 0 ? result[0] : undefined;
  }

  async createCollection(collectionData: InsertCollection): Promise<Collection> {
    const result = await db.insert(collections)
      .values(collectionData)
      .returning();
    
    return result[0];
  }

  async getUserCollections(userId: number): Promise<Collection[]> {
    return db.select()
      .from(collections)
      .where(eq(collections.ownerId, userId));
  }

  async getAllCollections(): Promise<Collection[]> {
    return db.select().from(collections);
  }

  // Activity operations
  async createActivity(activityData: InsertActivity): Promise<Activity> {
    const result = await db.insert(activity)
      .values(activityData)
      .returning();
    
    return result[0];
  }

  async getUserActivity(userId: number): Promise<Activity[]> {
    return db.select()
      .from(activity)
      .where(eq(activity.userId, userId))
      .orderBy(desc(activity.timestamp));
  }
}

// Create an admin user for initialization if none exists
async function initializeAdminUser(storage: DatabaseStorage) {
  const adminEmail = "admin@metaminter.com";
  const existingAdmin = await storage.getUserByEmail(adminEmail);
  
  if (!existingAdmin) {
    // Create default admin user
    await storage.createUser({
      username: "admin",
      password: "admin123", // This should be securely hashed in a real application
      email: adminEmail,
      firstName: "Admin",
      lastName: "User",
      isAdmin: true,
      isVerified: true,
      walletAddress: "0x1234567890abcdef1234567890abcdef12345678",
      bio: "MetaMinter platform administrator",
      // TypeScript requires this even though it's removed in createUser
      confirmPassword: "admin123",
    });
    console.log("Default admin user created");
  }
}

// Initialize the database storage
export const storage = new DatabaseStorage();

// Initialize admin user
initializeAdminUser(storage).catch(err => {
  console.error("Error initializing admin user:", err);
});
