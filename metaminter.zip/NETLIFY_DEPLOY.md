# Deploying MetaMinter to Netlify

This document provides instructions for deploying your MetaMinter NFT platform to Netlify. MetaMinter is designed to work with the Ethereum blockchain and requires specific environment configurations.

## Prerequisites

- A Netlify account (free tier is available)
- A GitHub account to host your repository
- A PostgreSQL database service for backend storage
- An Ethereum wallet to receive the 0.52 ETH minting fee

## Deployment Steps

### 1. Push your code to GitHub

First, create a new GitHub repository and push your code:

```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/your-username/your-repo-name.git
git push -u origin main
```

### 2. Deploy to Netlify

#### Option 1: Deploy through the Netlify UI

1. Log in to your Netlify account at https://app.netlify.com/
2. Click "Add new site" > "Import an existing project"
3. Connect to your GitHub account
4. Select your repository
5. Netlify will automatically detect the settings from netlify.toml
6. Click "Deploy site"

#### Option 2: Deploy with Netlify CLI

1. Install the Netlify CLI: `npm install netlify-cli -g`
2. Login to Netlify: `netlify login`
3. Initialize your site: `netlify init`
4. Deploy your site: `netlify deploy --prod`

### 3. Configure Environment Variables

After deployment, set up your environment variables in the Netlify dashboard:

1. Go to Site settings > Build & deploy > Environment
2. Add the following variables:
   - `VITE_STRIPE_PUBLIC_KEY` (if using Stripe)
   - Any other API keys your application needs

### 4. Set up a Custom Domain (Optional)

1. In the Netlify dashboard, go to Site settings > Domain management
2. Click "Add custom domain"
3. Follow the instructions to configure your domain

## Important Notes

- This deployment only includes the frontend portion of your application
- For the backend and database, you'll need a separate service like Render.com, Railway.app, or similar
- Once you have a backend deployed, update the `VITE_API_URL` in Netlify's environment variables to point to your backend

## Claim URL

Your Netlify deployment will be available at:
https://your-site-name.netlify.app

Where "your-site-name" is either:
- A random name assigned by Netlify, or
- A custom name you set in the Netlify dashboard under Site settings > General > Site details > Change site name