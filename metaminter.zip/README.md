# MetaMinter

A professional NFT minting platform with MetaMask wallet integration.

## Features

- User authentication with admin verification
- MetaMask wallet integration
- Fixed 0.52 ETH minting fee
- Password reset via email verification
- NFT collection management
- Purchase and ownership tracking
- Activity history

## Technology Stack

- React.js frontend
- Typescript
- Drizzle ORM with PostgreSQL
- Express.js backend
- MetaMask for Ethereum blockchain interactions
