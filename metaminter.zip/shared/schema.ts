import { pgTable, text, serial, integer, boolean, timestamp, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  email: text("email").notNull().unique(),
  bio: text("bio"),
  walletAddress: text("wallet_address"),
  isVerified: boolean("is_verified").default(false),
  isAdmin: boolean("is_admin").default(false),
  registeredAt: timestamp("registered_at").defaultNow(),
  resetToken: text("reset_token"),
  resetTokenExpiry: timestamp("reset_token_expiry"),
});

export const nfts = pgTable("nfts", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  imageUrl: text("image_url").notNull(),
  ownerId: integer("owner_id").notNull(),
  tokenId: text("token_id"),
  collection: text("collection"),
  price: text("price").default("0.52"),
  mintedAt: timestamp("minted_at").defaultNow(),
  lastSoldAt: timestamp("last_sold_at"),
  lastSoldPrice: text("last_sold_price"),
});

export const collections = pgTable("collections", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  ownerId: integer("owner_id").notNull(),
});

export const activity = pgTable("activity", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  nftId: integer("nft_id"),
  type: text("type").notNull(), // 'mint', 'purchase', 'transfer', etc.
  timestamp: timestamp("timestamp").defaultNow(),
  description: text("description"),
  transactionHash: text("transaction_hash"),
  // Include existing columns to avoid deletion warnings
  action: text("action"),
  details: text("details"),
});

// Schemas for insertion with validation
export const insertUserSchema = createInsertSchema(users)
  .omit({ id: true, registeredAt: true })
  .extend({
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Passwords do not match",
    path: ["confirmPassword"],
  });

export const loginUserSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export const forgotPasswordSchema = z.object({
  email: z.string().email("Invalid email address"),
});

export const resetPasswordSchema = z.object({
  token: z.string(),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"],
});

export const insertNftSchema = createInsertSchema(nfts)
  .omit({ id: true, mintedAt: true, tokenId: true });

export const insertCollectionSchema = createInsertSchema(collections)
  .omit({ id: true });

export const insertActivitySchema = createInsertSchema(activity)
  .omit({ id: true, timestamp: true, action: true, details: true });

// Define types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type ForgotPassword = z.infer<typeof forgotPasswordSchema>;
export type ResetPassword = z.infer<typeof resetPasswordSchema>;

export type NFT = typeof nfts.$inferSelect;
export type InsertNFT = z.infer<typeof insertNftSchema>;

export type Collection = typeof collections.$inferSelect;
export type InsertCollection = z.infer<typeof insertCollectionSchema>;

export type Activity = typeof activity.$inferSelect;
export type InsertActivity = z.infer<typeof insertActivitySchema>;
