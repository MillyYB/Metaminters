import { useState, useEffect } from 'react';
import { useLocation, Link } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Button } from '@/components/ui/button';
import { insertUserSchema } from '@shared/schema';
import { useAuth } from '@/hooks/use-auth';
import { RiNftFill } from 'react-icons/ri';
import { FaEthereum } from 'react-icons/fa';

// Create a modified schema with password confirmation
const formSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Invalid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string(),
  firstName: z.string().optional(),
  lastName: z.string().optional(),
  bio: z.string().optional(),
  walletAddress: z.string().optional(),
  isAdmin: z.boolean().default(false),
  isVerified: z.boolean().default(false),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

export default function Register() {
  const [_, setLocation] = useLocation();
  const { register, isAuthenticated } = useAuth();
  const [isLoading, setIsLoading] = useState(false);
  const [registered, setRegistered] = useState(false);

  // Redirect if already authenticated
  useEffect(() => {
    if (isAuthenticated) {
      setLocation('/dashboard');
    }
  }, [isAuthenticated, setLocation]);

  // Redirect to pending verification page if registered
  useEffect(() => {
    if (registered) {
      setLocation('/verify-pending');
    }
  }, [registered, setLocation]);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      username: '',
      email: '',
      password: '',
      confirmPassword: '',
      firstName: '',
      lastName: '',
      bio: '',
      isAdmin: false,
      isVerified: false,
    },
  });

  async function onSubmit(values: z.infer<typeof formSchema>) {
    try {
      setIsLoading(true);
      
      // Create a new object with the same structure as values
      const formattedValues = {
        username: values.username,
        email: values.email,
        password: values.password,
        confirmPassword: values.confirmPassword,
        isAdmin: values.isAdmin,
        isVerified: values.isVerified,
        // For optional fields, convert empty strings to undefined
        firstName: values.firstName === '' ? undefined : values.firstName,
        lastName: values.lastName === '' ? undefined : values.lastName,
        bio: values.bio === '' ? undefined : values.bio,
        walletAddress: values.walletAddress === '' ? undefined : values.walletAddress,
      };
      
      await register(formattedValues);
      setRegistered(true);
    } catch (error) {
      console.error('Registration error:', error);
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-gray-100 py-4">
        <div className="container mx-auto px-4 flex items-center justify-between">
          <Link href="/" className="flex items-center">
            <RiNftFill className="text-primary text-3xl mr-2" />
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-violet-600 to-indigo-600">MintPlazza</span>
          </Link>
          <Button variant="outline" size="sm" className="border-violet-600 text-violet-600 hover:bg-violet-50" asChild>
            <Link href="/login">Sign In</Link>
          </Button>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-xl w-full max-w-2xl p-8 relative overflow-hidden">
          {/* Decorative background elements */}
          <div className="absolute -top-24 -right-24 w-48 h-48 bg-gradient-to-r from-violet-200 to-indigo-200 rounded-full opacity-50 blur-2xl"></div>
          <div className="absolute -bottom-24 -left-24 w-48 h-48 bg-gradient-to-r from-pink-200 to-purple-200 rounded-full opacity-50 blur-2xl"></div>
          
          <div className="relative z-10">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold mb-2 text-gray-900">Create Your Account</h2>
              <p className="text-gray-600">Join MintPlazza to start creating and collecting NFTs</p>
            </div>
            
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">First Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="John" 
                            {...field}
                            value={field.value || ''}
                            disabled={isLoading}
                            className="rounded-lg border-gray-300 focus:border-violet-500 focus:ring-violet-500" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Last Name</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="Doe" 
                            {...field}
                            value={field.value || ''}
                            disabled={isLoading}
                            className="rounded-lg border-gray-300 focus:border-violet-500 focus:ring-violet-500" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Username</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="johndoe" 
                          {...field} 
                          disabled={isLoading}
                          className="rounded-lg border-gray-300 focus:border-violet-500 focus:ring-violet-500" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-gray-700">Email</FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="your@email.com" 
                          {...field} 
                          type="email"
                          disabled={isLoading}
                          className="rounded-lg border-gray-300 focus:border-violet-500 focus:ring-violet-500" 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                  <FormField
                    control={form.control}
                    name="password"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Password</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="••••••••" 
                            {...field} 
                            type="password"
                            disabled={isLoading}
                            className="rounded-lg border-gray-300 focus:border-violet-500 focus:ring-violet-500" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="confirmPassword"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gray-700">Confirm Password</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="••••••••" 
                            {...field} 
                            type="password"
                            disabled={isLoading}
                            className="rounded-lg border-gray-300 focus:border-violet-500 focus:ring-violet-500" 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                
                <div className="flex items-center space-x-2">
                  <Checkbox id="terms" required className="text-violet-600 focus:ring-violet-500" />
                  <label
                    htmlFor="terms"
                    className="text-sm text-gray-600"
                  >
                    I agree to the{' '}
                    <Link href="/terms" className="text-violet-600 hover:text-violet-700 font-medium">
                      Terms
                    </Link>{' '}
                    and{' '}
                    <Link href="/privacy" className="text-violet-600 hover:text-violet-700 font-medium">
                      Privacy Policy
                    </Link>
                  </label>
                </div>
                
                <div className="bg-violet-50 rounded-lg p-4 border border-violet-100 flex items-center">
                  <FaEthereum className="text-violet-600 text-xl mr-3" />
                  <div>
                    <h4 className="font-medium text-gray-900">Admin Verification Required</h4>
                    <p className="text-sm text-gray-600">Your account will need to be verified by an admin before you can mint NFTs.</p>
                  </div>
                </div>
                
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-violet-600 to-indigo-600 hover:from-violet-700 hover:to-indigo-700" 
                  disabled={isLoading}
                >
                  {isLoading ? 'Creating Account...' : 'Create Account'}
                </Button>
              </form>
            </Form>
            
            <div className="mt-8 text-center">
              <p className="text-gray-600">
                Already have an account?{' '}
                <Link href="/login" className="text-violet-600 hover:text-violet-700 font-medium">
                  Sign in
                </Link>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
