import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { resetPasswordSchema } from '@shared/schema';
import { AnimatedHeader } from '@/components/layout/animated-header';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { LoadingButton } from '@/components/ui/loading-states';
import { CheckCircle, AlertCircle } from 'lucide-react';

export default function ResetPassword() {
  const { toast } = useToast();
  const [location, navigate] = useLocation();
  const [token, setToken] = useState<string | null>(null);
  const [resetStatus, setResetStatus] = useState<'idle' | 'success' | 'error'>('idle');
  
  // Get token from URL
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const tokenParam = params.get('token');
    if (tokenParam) {
      setToken(tokenParam);
    } else {
      toast({
        title: 'Error',
        description: 'Invalid or missing reset token',
        variant: 'destructive'
      });
      navigate('/forgot-password');
    }
  }, [navigate, toast]);

  const form = useForm<z.infer<typeof resetPasswordSchema>>({
    resolver: zodResolver(resetPasswordSchema),
    defaultValues: {
      token: '',
      password: '',
      confirmPassword: ''
    }
  });

  // Update form when token is available
  useEffect(() => {
    if (token) {
      form.setValue('token', token);
    }
  }, [token, form]);

  const resetPasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof resetPasswordSchema>) => {
      const response = await apiRequest('POST', '/api/auth/reset-password', data);
      return await response.json();
    },
    onSuccess: () => {
      setResetStatus('success');
    },
    onError: (error: Error) => {
      setResetStatus('error');
      toast({
        title: 'Error',
        description: error.message || 'Failed to reset password',
        variant: 'destructive'
      });
    }
  });

  const onSubmit = (data: z.infer<typeof resetPasswordSchema>) => {
    resetPasswordMutation.mutate(data);
  };

  if (!token) {
    return (
      <div className="flex min-h-screen flex-col">
        <AnimatedHeader />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
            <h1 className="text-2xl font-bold mb-2">Invalid Reset Link</h1>
            <p className="text-muted-foreground mb-4">
              The password reset link is invalid or expired.
            </p>
            <Button asChild>
              <Link to="/forgot-password">Request New Reset Link</Link>
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="flex min-h-screen flex-col">
      <AnimatedHeader />
      
      <main className="flex-1 flex items-center justify-center bg-gradient-to-b from-background to-background/80 py-10">
        <div className="container px-4 md:px-6">
          <div className="grid lg:grid-cols-2 gap-6 items-center">
            {/* Form Section */}
            <div className="max-w-md w-full mx-auto space-y-6 bg-background/60 dark:bg-gray-900/60 p-6 lg:p-8 rounded-xl backdrop-blur-sm border border-border shadow-lg">
              {resetStatus === 'idle' && (
                <>
                  <div className="space-y-2 text-center">
                    <h1 className="text-3xl font-bold">Reset Your Password</h1>
                    <p className="text-muted-foreground">
                      Create a new password for your MetaMinter account
                    </p>
                  </div>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>New Password</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter new password" type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="confirmPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Confirm Password</FormLabel>
                            <FormControl>
                              <Input placeholder="Confirm new password" type="password" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <LoadingButton 
                        type="submit"
                        className="w-full"
                        isLoading={resetPasswordMutation.isPending}
                        loadingText="Resetting..."
                        spinnerVariant="chain"
                      >
                        Reset Password
                      </LoadingButton>
                    </form>
                  </Form>
                </>
              )}
              
              {resetStatus === 'success' && (
                <div className="text-center space-y-6 py-8">
                  <div className="mx-auto bg-green-100 dark:bg-green-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center">
                    <CheckCircle className="h-8 w-8 text-green-600 dark:text-green-500" />
                  </div>
                  <h2 className="text-2xl font-bold">Password Reset Successful</h2>
                  <p className="text-muted-foreground">
                    Your password has been reset successfully. You can now log in with your new password.
                  </p>
                  <Button asChild className="mt-4">
                    <Link to="/login">Go to Login</Link>
                  </Button>
                </div>
              )}
              
              {resetStatus === 'error' && (
                <div className="text-center space-y-6 py-8">
                  <div className="mx-auto bg-red-100 dark:bg-red-900/30 p-3 rounded-full w-16 h-16 flex items-center justify-center">
                    <AlertCircle className="h-8 w-8 text-red-600 dark:text-red-500" />
                  </div>
                  <h2 className="text-2xl font-bold">Password Reset Failed</h2>
                  <p className="text-muted-foreground">
                    There was an error resetting your password. The link may be expired or invalid.
                  </p>
                  <div className="flex flex-col space-y-2 sm:flex-row sm:space-x-2 sm:space-y-0 justify-center">
                    <Button asChild variant="outline">
                      <Link to="/forgot-password">Request New Link</Link>
                    </Button>
                    <Button asChild>
                      <Link to="/login">Return to Login</Link>
                    </Button>
                  </div>
                </div>
              )}
            </div>
            
            {/* Info Section */}
            <div className="hidden lg:flex flex-col justify-center space-y-6">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold">Secure Your MetaMinter Account</h2>
                <p className="text-lg text-muted-foreground">
                  Creating a strong password helps protect your valuable NFT assets.
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-[25px_1fr] items-start gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">1</div>
                  <div>
                    <h3 className="font-medium">Create a Strong Password</h3>
                    <p className="text-sm text-muted-foreground">Use a combination of letters, numbers, and special characters.</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-[25px_1fr] items-start gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">2</div>
                  <div>
                    <h3 className="font-medium">Don't Reuse Passwords</h3>
                    <p className="text-sm text-muted-foreground">Using unique passwords for different websites enhances your security.</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-[25px_1fr] items-start gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">3</div>
                  <div>
                    <h3 className="font-medium">Keep Your Password Safe</h3>
                    <p className="text-sm text-muted-foreground">Never share your password or store it in plain text.</p>
                  </div>
                </div>
              </div>
              
              <div className="rounded-xl bg-muted p-6 border border-border">
                <p className="text-sm">
                  "Security is a top priority for NFT collectors. I appreciate how MetaMinter takes account 
                  security seriously." — <span className="font-medium">Michael T., NFT Collector</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}