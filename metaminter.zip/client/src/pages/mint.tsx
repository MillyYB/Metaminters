import { useState, useEffect, useRef } from 'react';
import { useLocation } from 'wouter';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Header } from '@/components/layout/header';
import { Card, CardContent } from '@/components/ui/card';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useMetamask } from '@/hooks/use-metamask';
import { apiRequest } from '@/lib/queryClient';
import { Collection } from '@shared/schema';
import { motion } from 'framer-motion';
import { FaUpload, FaFire } from 'react-icons/fa';

const formSchema = z.object({
  name: z.string().min(1, 'NFT name is required'),
  description: z.string().optional(),
  collection: z.string().optional(),
  imageUrl: z.string().min(1, 'Image is required'),
});

type FormValues = z.infer<typeof formSchema>;

export default function Mint() {
  const [_, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { mintNFT } = useMetamask();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isConfirmDialogOpen, setIsConfirmDialogOpen] = useState(false);
  const [formValues, setFormValues] = useState<FormValues | null>(null);

  // Redirect if not authenticated or not verified
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation('/login');
    } else if (user && !user.isVerified) {
      setLocation('/verify-pending');
    }
  }, [isAuthenticated, user, setLocation]);

  // Fetch collections
  const { data: collections } = useQuery<Collection[]>({
    queryKey: ['/api/collections'],
    enabled: !!isAuthenticated,
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      description: '',
      collection: '',
      imageUrl: '',
    },
  });

  // Mutation to create NFT
  const createNftMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      return apiRequest('POST', '/api/nfts', data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/nfts/user'] });
      queryClient.invalidateQueries({ queryKey: ['/api/activity'] });
      
      toast({
        title: 'NFT Minted Successfully',
        description: 'Your new NFT has been created',
      });
      
      setLocation('/gallery');
    },
    onError: (error: Error) => {
      toast({
        title: 'Minting Failed',
        description: error.message,
        variant: 'destructive',
      });
    },
  });

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Simulate file upload with a brief delay
    setIsUploading(true);
    
    // Mock uploading to simulate this would go to a real storage service
    setTimeout(() => {
      // For demo purposes, create a local object URL
      // In a real app, this would be the URL returned from the upload service
      const objectUrl = URL.createObjectURL(file);
      setPreviewUrl(objectUrl);
      form.setValue('imageUrl', objectUrl);
      setIsUploading(false);
    }, 1000);
  };

  const removePreview = () => {
    setPreviewUrl(null);
    form.setValue('imageUrl', '');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const onSubmit = async (data: FormValues) => {
    setFormValues(data);
    setIsConfirmDialogOpen(true);
  };

  const handleConfirmMint = async () => {
    if (!formValues) return;
    
    // First process the payment with MetaMask
    const success = await mintNFT('0.52');
    if (success) {
      // Then create the NFT record
      createNftMutation.mutate(formValues);
    }
    
    setIsConfirmDialogOpen(false);
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-blue-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Mint Your NFT</h1>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Preview Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold mb-4">NFT Preview</h2>
                
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 mb-4 flex items-center justify-center bg-gray-50 h-80 relative">
                  {!previewUrl ? (
                    <div className="text-center">
                      <div className="text-4xl text-gray-400 mb-2">
                        <FaUpload className="mx-auto" />
                      </div>
                      <p className="text-gray-500">Upload your artwork to preview</p>
                      <p className="text-gray-400 text-sm mt-2">Supports JPG, PNG, GIF, SVG, MP4</p>
                      <p className="text-gray-400 text-sm">Max size: 50MB</p>
                    </div>
                  ) : (
                    <div className="w-full h-full relative">
                      <img
                        src={previewUrl}
                        alt="NFT Preview"
                        className="w-full h-full object-contain"
                      />
                      <button
                        type="button"
                        className="absolute top-2 right-2 bg-gray-800 bg-opacity-70 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-opacity-100"
                        onClick={removePreview}
                      >
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                        </svg>
                      </button>
                    </div>
                  )}
                  
                  {isUploading && (
                    <div className="absolute inset-0 bg-white bg-opacity-80 flex items-center justify-center">
                      <div className="text-center">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
                        <p className="mt-2 text-gray-600">Uploading...</p>
                      </div>
                    </div>
                  )}
                </div>
                
                <div className="flex justify-center">
                  <input
                    type="file"
                    ref={fileInputRef}
                    className="hidden"
                    id="nft-upload"
                    accept="image/*,video/mp4"
                    onChange={handleFileChange}
                    disabled={isUploading}
                  />
                  <Button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    disabled={isUploading}
                  >
                    <FaUpload className="mr-2" /> Upload File
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
          
          {/* Form Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: 0.1 }}
          >
            <Card>
              <CardContent className="pt-6">
                <h2 className="text-lg font-semibold mb-4">NFT Details</h2>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>NFT Name</FormLabel>
                          <FormControl>
                            <Input placeholder="e.g. Cosmic Voyager #42" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea
                              placeholder="Describe your NFT..."
                              className="resize-none"
                              rows={3}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="collection"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Collection</FormLabel>
                          <Select
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select a collection" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {collections && collections.map((collection) => (
                                <SelectItem key={collection.id} value={collection.name}>
                                  {collection.name}
                                </SelectItem>
                              ))}
                              <SelectItem value="create-new">Create New Collection...</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div>
                      <FormLabel>Properties (Optional)</FormLabel>
                      <div className="border border-gray-300 rounded-lg p-4">
                        <div className="grid grid-cols-2 gap-4 mb-4">
                          <Input placeholder="Type (e.g. Color)" />
                          <Input placeholder="Value (e.g. Blue)" />
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="text-primary"
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clipRule="evenodd" />
                          </svg>
                          Add Property
                        </Button>
                      </div>
                    </div>
                    
                    <div>
                      <FormLabel>Minting Fee</FormLabel>
                      <div className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50 font-mono">
                        0.52 ETH
                      </div>
                      <p className="text-sm text-gray-500 mt-1">
                        This is a fixed fee for all mints on our platform.
                      </p>
                    </div>
                    
                    <Button
                      type="submit"
                      className="w-full py-6"
                      disabled={!form.formState.isValid || createNftMutation.isPending}
                    >
                      <FaFire className="mr-2" /> Mint NFT
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </main>
      
      {/* Confirmation Dialog */}
      <Dialog open={isConfirmDialogOpen} onOpenChange={setIsConfirmDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm NFT Minting</DialogTitle>
            <DialogDescription>
              You are about to mint your NFT. This action will cost 0.52 ETH and cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <div className="mt-4 bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm text-gray-500">Minting Fee:</span>
              <span className="font-mono">0.52 ETH</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-500">Gas Fee (estimated):</span>
              <span className="font-mono">0.003 ETH</span>
            </div>
            <div className="border-t border-gray-200 my-2"></div>
            <div className="flex justify-between items-center font-medium">
              <span>Total:</span>
              <span className="font-mono">0.523 ETH</span>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setIsConfirmDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              onClick={handleConfirmMint}
              disabled={createNftMutation.isPending}
            >
              {createNftMutation.isPending ? 'Processing...' : 'Confirm Mint'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
