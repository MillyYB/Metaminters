import { useState } from 'react';
import { Link } from 'wouter';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { forgotPasswordSchema } from '@shared/schema';
import { AnimatedHeader } from '@/components/layout/animated-header';
import { Footer } from '@/components/layout/footer';
import { Button } from '@/components/ui/button';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';
import { LoadingButton } from '@/components/ui/loading-states';
import { CircleDollarSign } from 'lucide-react';

export default function ForgotPassword() {
  const { toast } = useToast();
  const [emailSent, setEmailSent] = useState(false);
  
  const form = useForm<z.infer<typeof forgotPasswordSchema>>({
    resolver: zodResolver(forgotPasswordSchema),
    defaultValues: {
      email: ''
    }
  });

  const forgotPasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof forgotPasswordSchema>) => {
      const response = await apiRequest('POST', '/api/auth/forgot-password', data);
      return await response.json();
    },
    onSuccess: () => {
      setEmailSent(true);
    },
    onError: (error: Error) => {
      toast({
        title: 'Error',
        description: error.message || 'Failed to request password reset',
        variant: 'destructive'
      });
    }
  });

  const onSubmit = (data: z.infer<typeof forgotPasswordSchema>) => {
    forgotPasswordMutation.mutate(data);
  };

  return (
    <div className="flex min-h-screen flex-col">
      <AnimatedHeader />
      
      <main className="flex-1 flex items-center justify-center bg-gradient-to-b from-background to-background/80 py-10">
        <div className="container px-4 md:px-6">
          <div className="grid lg:grid-cols-2 gap-6 items-center">
            {/* Form Section */}
            <div className="max-w-md w-full mx-auto space-y-6 bg-background/60 dark:bg-gray-900/60 p-6 lg:p-8 rounded-xl backdrop-blur-sm border border-border shadow-lg">
              {!emailSent ? (
                <>
                  <div className="space-y-2 text-center">
                    <h1 className="text-3xl font-bold">Forgot Password</h1>
                    <p className="text-muted-foreground">
                      Enter your email address and we'll send you a link to reset your password.
                    </p>
                  </div>
                  
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email</FormLabel>
                            <FormControl>
                              <Input placeholder="Your email address" type="email" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <LoadingButton 
                        type="submit"
                        className="w-full"
                        isLoading={forgotPasswordMutation.isPending}
                        loadingText="Sending..."
                        spinnerVariant="chain"
                      >
                        Send Reset Link
                      </LoadingButton>
                      
                      <div className="text-center">
                        <Link to="/login" className="text-sm text-primary hover:underline">
                          Back to Login
                        </Link>
                      </div>
                    </form>
                  </Form>
                </>
              ) : (
                <div className="text-center space-y-6 py-8">
                  <div className="mx-auto bg-primary/10 p-3 rounded-full w-16 h-16 flex items-center justify-center">
                    <CircleDollarSign className="h-8 w-8 text-primary" />
                  </div>
                  <h2 className="text-2xl font-bold">Check Your Email</h2>
                  <p className="text-muted-foreground">
                    If your email is registered with MetaMinter, you will receive a password reset link shortly.
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Make sure to check your spam folder if you don't see it in your inbox.
                  </p>
                  <Button asChild variant="outline" className="mt-4">
                    <Link to="/login">Return to Login</Link>
                  </Button>
                </div>
              )}
            </div>
            
            {/* Info Section */}
            <div className="hidden lg:flex flex-col justify-center space-y-6">
              <div className="space-y-2">
                <h2 className="text-3xl font-bold">MetaMinter Password Recovery</h2>
                <p className="text-lg text-muted-foreground">
                  Recover access to your MetaMinter account and continue your NFT journey.
                </p>
              </div>
              
              <div className="space-y-4">
                <div className="grid grid-cols-[25px_1fr] items-start gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">1</div>
                  <div>
                    <h3 className="font-medium">Enter Your Email</h3>
                    <p className="text-sm text-muted-foreground">Provide the email address you used during registration.</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-[25px_1fr] items-start gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">2</div>
                  <div>
                    <h3 className="font-medium">Check Your Email</h3>
                    <p className="text-sm text-muted-foreground">We'll send a secure reset link to your email address.</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-[25px_1fr] items-start gap-2">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary text-primary-foreground text-xs">3</div>
                  <div>
                    <h3 className="font-medium">Set a New Password</h3>
                    <p className="text-sm text-muted-foreground">Create a new secure password and regain access to your account.</p>
                  </div>
                </div>
              </div>
              
              <div className="rounded-xl bg-muted p-6 border border-border">
                <p className="text-sm">
                  "MetaMinter has revolutionized the way I create and trade NFTs. The platform is intuitive and 
                  the community is fantastic!" — <span className="font-medium">Sarah K., Digital Artist</span>
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}