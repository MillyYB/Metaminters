import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { motion } from 'framer-motion';
import { FaClock } from 'react-icons/fa';

export default function VerifyPending() {
  const [_, setLocation] = useLocation();
  const { isAuthenticated, user, logout } = useAuth();

  // If user is authenticated and verified, redirect to dashboard
  useEffect(() => {
    if (isAuthenticated && user?.isVerified) {
      setLocation('/dashboard');
    } else if (!isAuthenticated) {
      setLocation('/login');
    }
  }, [isAuthenticated, user, setLocation]);

  const handleBackToLogin = async () => {
    await logout();
    setLocation('/login');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-blue-50">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-md bg-white rounded-xl shadow-lg p-8 text-center"
      >
        <motion.div
          initial={{ y: 20 }}
          animate={{ y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
          className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6"
        >
          <FaClock className="text-4xl text-yellow-500" />
        </motion.div>
        
        <motion.h2
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.5 }}
          className="text-2xl font-bold mb-2 text-gray-900"
        >
          Verification Pending
        </motion.h2>
        
        <motion.p
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="text-gray-600 mb-6"
        >
          Your account is awaiting approval from an administrator. You'll receive an email once your account is verified.
        </motion.p>
        
        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.5, duration: 0.5 }}
        >
          <Button
            variant="outline"
            onClick={handleBackToLogin}
          >
            Back to Login
          </Button>
        </motion.div>
      </motion.div>
    </div>
  );
}
