import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { BlockchainSpinner } from '@/components/ui/blockchain-spinner';
import { LoadingState, LoadingButton, LoadingContainer } from '@/components/ui/loading-states';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';

export default function LoadingDemo() {
  const [variant, setVariant] = useState<'ethereum' | 'chain' | 'blocks' | 'nodes'>('ethereum');
  const [size, setSize] = useState<'sm' | 'md' | 'lg' | 'xl'>('md');
  const [customText, setCustomText] = useState('');
  const [isFullscreenLoading, setIsFullscreenLoading] = useState(false);
  const [containerLoading, setContainerLoading] = useState(false);
  const [simulateButtonLoading, setSimulateButtonLoading] = useState(false);
  const { toast } = useToast();

  // Helper function to simulate loading states
  const simulateLoading = (callback: (state: boolean) => void, duration = 3000) => {
    callback(true);
    setTimeout(() => callback(false), duration);
  };

  return (
    <div className="container px-4 py-8 mx-auto max-w-6xl">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="grid gap-8"
      >
        <div className="text-center">
          <motion.h1 
            className="text-3xl font-bold mb-2 bg-clip-text text-transparent bg-gradient-to-r from-red-500 to-red-700"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
          >
            Blockchain Loading States
          </motion.h1>
          <motion.p 
            className="text-gray-400 max-w-2xl mx-auto"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            A collection of animated loading states with blockchain themes for use throughout the application
          </motion.p>
        </div>

        <Tabs defaultValue="spinners" className="w-full">
          <TabsList className="grid grid-cols-4 mb-8">
            <TabsTrigger value="spinners">Spinner Variants</TabsTrigger>
            <TabsTrigger value="states">Loading States</TabsTrigger>
            <TabsTrigger value="buttons">Loading Buttons</TabsTrigger>
            <TabsTrigger value="containers">Loading Containers</TabsTrigger>
          </TabsList>
          
          {/* SPINNER VARIANTS */}
          <TabsContent value="spinners" className="space-y-8">
            <div className="p-6 bg-black/40 rounded-xl border border-red-500/20 shadow-lg">
              <h2 className="text-xl font-bold mb-6 text-white">Spinner Variants</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div className="flex flex-col items-center p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Ethereum</h3>
                  <BlockchainSpinner variant="ethereum" size={size} text="Loading..." />
                </div>
                
                <div className="flex flex-col items-center p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Chain</h3>
                  <BlockchainSpinner variant="chain" size={size} text="Loading..." />
                </div>
                
                <div className="flex flex-col items-center p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Blocks</h3>
                  <BlockchainSpinner variant="blocks" size={size} text="Loading..." />
                </div>
                
                <div className="flex flex-col items-center p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Nodes</h3>
                  <BlockchainSpinner variant="nodes" size={size} text="Loading..." />
                </div>
              </div>
              
              <div className="mt-8 grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="text-white font-medium">Size</h3>
                  <div className="flex space-x-4">
                    {(['sm', 'md', 'lg', 'xl'] as const).map((sizeOption) => (
                      <div key={sizeOption} className="flex items-center space-x-2">
                        <input
                          type="radio"
                          id={`size-${sizeOption}`}
                          name="size"
                          value={sizeOption}
                          checked={size === sizeOption}
                          onChange={() => setSize(sizeOption)}
                          className="text-red-500 focus:ring-red-500"
                        />
                        <label htmlFor={`size-${sizeOption}`} className="text-gray-300">
                          {sizeOption.toUpperCase()}
                        </label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
          
          {/* LOADING STATES */}
          <TabsContent value="states" className="space-y-8">
            <div className="p-6 bg-black/40 rounded-xl border border-red-500/20 shadow-lg">
              <h2 className="text-xl font-bold mb-6 text-white">Loading State Types</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Inline Loading</h3>
                  <div className="h-32 flex items-center justify-center">
                    <LoadingState 
                      type="inline" 
                      variant={variant} 
                      size={size} 
                      text={customText || "Loading..."} 
                    />
                  </div>
                </div>
                
                <div className="p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Fullscreen Loading</h3>
                  <div className="h-32 flex items-center justify-center">
                    <Button 
                      onClick={() => simulateLoading(setIsFullscreenLoading, 3000)}
                      className="bg-red-600 hover:bg-red-700 text-white"
                    >
                      Show Fullscreen Loading (3s)
                    </Button>
                    
                    {isFullscreenLoading && (
                      <LoadingState 
                        type="fullscreen" 
                        variant={variant} 
                        text={customText || "Loading content..."} 
                      />
                    )}
                  </div>
                </div>
              </div>
              
              <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <h3 className="text-white font-medium">Variant</h3>
                  <Select 
                    value={variant} 
                    onValueChange={(value) => setVariant(value as any)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select variant" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ethereum">Ethereum</SelectItem>
                      <SelectItem value="chain">Chain</SelectItem>
                      <SelectItem value="blocks">Blocks</SelectItem>
                      <SelectItem value="nodes">Nodes</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-white font-medium">Size</h3>
                  <Select 
                    value={size} 
                    onValueChange={(value) => setSize(value as any)}
                  >
                    <SelectTrigger className="w-full">
                      <SelectValue placeholder="Select size" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sm">Small</SelectItem>
                      <SelectItem value="md">Medium</SelectItem>
                      <SelectItem value="lg">Large</SelectItem>
                      <SelectItem value="xl">Extra Large</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="space-y-4">
                  <h3 className="text-white font-medium">Custom Text</h3>
                  <input
                    type="text"
                    value={customText}
                    onChange={(e) => setCustomText(e.target.value)}
                    placeholder="Custom loading text..."
                    className="w-full px-3 py-2 bg-black border border-red-500/30 rounded-md text-white"
                  />
                </div>
              </div>
            </div>
          </TabsContent>
          
          {/* LOADING BUTTONS */}
          <TabsContent value="buttons" className="space-y-8">
            <div className="p-6 bg-black/40 rounded-xl border border-red-500/20 shadow-lg">
              <h2 className="text-xl font-bold mb-6 text-white">Loading Buttons</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Primary Button</h3>
                  <div className="flex justify-center">
                    <LoadingButton 
                      isLoading={simulateButtonLoading}
                      loadingText="Processing..."
                      spinnerVariant={variant}
                      onClick={() => {
                        simulateLoading(setSimulateButtonLoading);
                        toast({
                          title: "Transaction initiated",
                          description: "Processing your mint request...",
                        });
                      }}
                      className="bg-red-600 hover:bg-red-700 text-white py-2.5 px-5 rounded-lg font-medium"
                    >
                      Mint NFT
                    </LoadingButton>
                  </div>
                </div>
                
                <div className="p-6 bg-gray-900/50 rounded-lg border border-red-500/10">
                  <h3 className="text-lg font-semibold mb-4 text-red-400">Secondary Button</h3>
                  <div className="flex justify-center">
                    <LoadingButton 
                      isLoading={simulateButtonLoading}
                      loadingText="Connecting..."
                      spinnerVariant={variant}
                      onClick={() => {
                        simulateLoading(setSimulateButtonLoading);
                        toast({
                          title: "Wallet Connection",
                          description: "Connecting to your wallet...",
                        });
                      }}
                      className="bg-gray-800 hover:bg-gray-700 text-white border border-red-500/40 py-2.5 px-5 rounded-lg font-medium"
                    >
                      Connect Wallet
                    </LoadingButton>
                  </div>
                </div>
              </div>
              
              <div className="mt-8">
                <h3 className="text-white font-medium mb-4">Button Variants</h3>
                <div className="flex flex-wrap gap-4">
                  <LoadingButton 
                    isLoading={simulateButtonLoading}
                    spinnerVariant="ethereum"
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Ethereum
                  </LoadingButton>
                  
                  <LoadingButton 
                    isLoading={simulateButtonLoading}
                    spinnerVariant="chain"
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Chain
                  </LoadingButton>
                  
                  <LoadingButton 
                    isLoading={simulateButtonLoading}
                    spinnerVariant="blocks"
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Blocks
                  </LoadingButton>
                  
                  <LoadingButton 
                    isLoading={simulateButtonLoading}
                    spinnerVariant="nodes"
                    className="bg-red-600 hover:bg-red-700 text-white"
                  >
                    Nodes
                  </LoadingButton>
                </div>
              </div>
            </div>
          </TabsContent>
          
          {/* LOADING CONTAINERS */}
          <TabsContent value="containers" className="space-y-8">
            <div className="p-6 bg-black/40 rounded-xl border border-red-500/20 shadow-lg">
              <h2 className="text-xl font-bold mb-6 text-white">Loading Containers</h2>
              
              <div className="p-6 bg-gray-900/50 rounded-lg border border-red-500/10 mb-8">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold text-red-400">Content With Overlay</h3>
                  <Button 
                    variant="outline" 
                    onClick={() => simulateLoading(setContainerLoading, 3000)}
                    className="border-red-500/40 text-red-400 hover:bg-red-950"
                  >
                    Toggle Loading
                  </Button>
                </div>
                
                <LoadingContainer 
                  isLoading={containerLoading} 
                  loadingText="Loading content..."
                  spinnerVariant={variant}
                  spinnerSize={size}
                  className="min-h-[300px]"
                >
                  <div className="p-6 border border-gray-800 rounded-lg">
                    <h3 className="text-xl font-bold mb-4 text-white">NFT Content</h3>
                    <p className="text-gray-400 mb-4">
                      This is an example of content that would be loaded from the blockchain. When data is being
                      fetched, the loading overlay will appear over this entire container.
                    </p>
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      {[1, 2, 3].map((item) => (
                        <div key={item} className="bg-gray-800 p-4 rounded-lg">
                          <div className="aspect-square bg-gray-700 rounded-md mb-2"></div>
                          <div className="h-4 bg-gray-700 rounded-full w-3/4 mb-2"></div>
                          <div className="h-3 bg-gray-700 rounded-full w-1/2"></div>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-end">
                      <Button 
                        className="bg-red-600 hover:bg-red-700"
                        disabled={containerLoading}
                      >
                        View All
                      </Button>
                    </div>
                  </div>
                </LoadingContainer>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </motion.div>
    </div>
  );
}