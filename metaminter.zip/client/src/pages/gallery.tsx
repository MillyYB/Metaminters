import { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Header } from '@/components/layout/header';
import { NFTCard } from '@/components/ui/nft-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/use-auth';
import { useMetamask } from '@/hooks/use-metamask';
import { NFT, Collection } from '@shared/schema';
import { Link } from 'wouter';
import { motion } from 'framer-motion';
import { FaSearch, FaEthereum } from 'react-icons/fa';
import { LoadingState } from '@/components/ui/loading-states';
import { useToast } from '@/hooks/use-toast';

export default function Gallery() {
  const [_, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();
  const { buyNFT, isConnected } = useMetamask();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState('');
  const [collectionFilter, setCollectionFilter] = useState('all');
  const [sortOrder, setSortOrder] = useState('recent');
  const [currentPage, setCurrentPage] = useState(1);
  const [purchasingNftId, setPurchasingNftId] = useState<number | null>(null);
  const itemsPerPage = 8;
  
  // Handle NFT Purchase
  const handlePurchase = async (nft: NFT) => {
    if (!isConnected) {
      toast({
        title: "Wallet not connected",
        description: "Please connect your MetaMask wallet first",
        variant: "destructive",
      });
      return;
    }
    
    if (!nft.price) {
      toast({
        title: "Price error",
        description: "This NFT doesn't have a valid price",
        variant: "destructive",
      });
      return;
    }
    
    setPurchasingNftId(nft.id);
    
    try {
      const success = await buyNFT(nft.id, nft.price);
      
      if (success) {
        // Invalidate queries to refresh data
        queryClient.invalidateQueries({ queryKey: ['/api/nfts'] });
        queryClient.invalidateQueries({ queryKey: ['/api/activity'] });
      }
    } catch (error) {
      console.error("Purchase error:", error);
      toast({
        title: "Purchase Failed",
        description: "There was an error completing your purchase",
        variant: "destructive",
      });
    } finally {
      setPurchasingNftId(null);
    }
  };

  // Redirect if not authenticated or not verified
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation('/login');
    } else if (user && !user.isVerified) {
      setLocation('/verify-pending');
    }
  }, [isAuthenticated, user, setLocation]);

  // Fetch all NFTs
  const { data: nfts, isLoading: isLoadingNfts } = useQuery<NFT[]>({
    queryKey: ['/api/nfts'],
    enabled: !!isAuthenticated,
  });

  // Fetch collections
  const { data: collections } = useQuery<Collection[]>({
    queryKey: ['/api/collections'],
    enabled: !!isAuthenticated,
  });

  // Filter and sort NFTs
  const filteredNfts = nfts
    ? nfts.filter((nft) => {
        const matchesSearch = nft.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                             (nft.description && nft.description.toLowerCase().includes(searchTerm.toLowerCase()));
        const matchesCollection = collectionFilter === 'all' || nft.collection === collectionFilter;
        return matchesSearch && matchesCollection;
      })
    : [];

  const sortedNfts = [...filteredNfts].sort((a, b) => {
    if (sortOrder === 'recent') {
      const dateA = a.mintedAt ? new Date(a.mintedAt) : new Date(0);
      const dateB = b.mintedAt ? new Date(b.mintedAt) : new Date(0);
      return dateB.getTime() - dateA.getTime();
    } else if (sortOrder === 'oldest') {
      const dateA = a.mintedAt ? new Date(a.mintedAt) : new Date(0);
      const dateB = b.mintedAt ? new Date(b.mintedAt) : new Date(0);
      return dateA.getTime() - dateB.getTime();
    } else if (sortOrder === 'highest') {
      return parseFloat(b.price || '0') - parseFloat(a.price || '0');
    } else if (sortOrder === 'lowest') {
      return parseFloat(a.price || '0') - parseFloat(b.price || '0');
    }
    return 0;
  });

  // Pagination
  const totalPages = Math.ceil(sortedNfts.length / itemsPerPage);
  const paginatedNfts = sortedNfts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const goToPage = (page: number) => {
    setCurrentPage(Math.max(1, Math.min(page, totalPages)));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="min-h-screen flex flex-col bg-black text-white">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
          className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6"
        >
          <h1 className="text-2xl font-bold mb-4 md:mb-0">NFT Gallery</h1>
          
          <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4 w-full md:w-auto">
            <div className="relative">
              <Input
                className="pl-10 w-full md:w-64"
                placeholder="Search NFTs..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
              <FaSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
            </div>
            
            <div className="flex space-x-2">
              <Select
                value={collectionFilter}
                onValueChange={setCollectionFilter}
              >
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="All Collections" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Collections</SelectItem>
                  {collections && collections.map((collection) => (
                    <SelectItem key={collection.id} value={collection.name}>
                      {collection.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select
                value={sortOrder}
                onValueChange={setSortOrder}
              >
                <SelectTrigger className="w-full sm:w-[180px]">
                  <SelectValue placeholder="Recently Added" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="recent">Recently Added</SelectItem>
                  <SelectItem value="oldest">Oldest First</SelectItem>
                  <SelectItem value="highest">Highest Value</SelectItem>
                  <SelectItem value="lowest">Lowest Value</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </motion.div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.4, delay: 0.1 }}
          className="relative"
        >
          {isLoadingNfts ? (
            <div className="py-20">
              <LoadingState 
                type="inline" 
                variant="blocks" 
                size="lg" 
                text="Loading NFT collection..." 
              />
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
              {paginatedNfts.length > 0 ? (
                paginatedNfts.map((nft) => (
                  <NFTCard 
                    key={nft.id} 
                    nft={nft} 
                    onPurchase={handlePurchase}
                    isPurchasing={purchasingNftId === nft.id}
                    showPurchaseButton={nft.ownerId !== user?.id && !!nft.price && parseFloat(nft.price || "0") > 0}
                  />
                ))
              ) : (
                <div className="col-span-full py-12 text-center">
                  <p className="text-gray-500 mb-4">No NFTs found matching your filters</p>
                  {searchTerm || collectionFilter !== 'all' ? (
                    <Button onClick={() => { setSearchTerm(''); setCollectionFilter('all'); }}>
                      Clear Filters
                    </Button>
                  ) : (
                    <Button asChild className="bg-red-600 hover:bg-red-700 text-white">
                      <Link href="/mint">Mint Your First NFT</Link>
                    </Button>
                  )}
                </div>
              )}
            </div>
          )}
        </motion.div>
        
        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex justify-center mt-8">
            <nav className="inline-flex rounded-md shadow-sm">
              <Button
                variant="outline"
                onClick={() => goToPage(currentPage - 1)}
                disabled={currentPage === 1}
                className="rounded-r-none"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              </Button>
              
              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                // Determine which page numbers to show
                let pageNum;
                if (totalPages <= 5) {
                  pageNum = i + 1;
                } else if (currentPage <= 3) {
                  pageNum = i + 1;
                } else if (currentPage >= totalPages - 2) {
                  pageNum = totalPages - 4 + i;
                } else {
                  pageNum = currentPage - 2 + i;
                }
                
                return (
                  <Button
                    key={i}
                    variant={pageNum === currentPage ? 'default' : 'outline'}
                    onClick={() => goToPage(pageNum)}
                    className="rounded-none border-x-0"
                  >
                    {pageNum}
                  </Button>
                );
              })}
              
              <Button
                variant="outline"
                onClick={() => goToPage(currentPage + 1)}
                disabled={currentPage === totalPages}
                className="rounded-l-none"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                </svg>
              </Button>
            </nav>
          </div>
        )}
      </main>
    </div>
  );
}
