import { useEffect } from 'react';
import { useLocation } from 'wouter';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Header } from '@/components/layout/header';
import { NFTCard } from '@/components/ui/nft-card';
import { StatsCard } from '@/components/ui/stats-card';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/hooks/use-auth';
import { Activity, NFT } from '@shared/schema';
import { formatDate, formatEth } from '@/lib/utils';
import { motion } from 'framer-motion';
import { FaImages, FaCoins, FaFire } from 'react-icons/fa';

export default function Dashboard() {
  const [_, setLocation] = useLocation();
  const { isAuthenticated, user } = useAuth();

  // Redirect if not authenticated or not verified
  useEffect(() => {
    if (!isAuthenticated) {
      setLocation('/login');
    } else if (user && !user.isVerified) {
      setLocation('/verify-pending');
    }
  }, [isAuthenticated, user, setLocation]);

  // Fetch user's NFTs
  const { data: nfts, isLoading: isLoadingNfts } = useQuery<NFT[]>({
    queryKey: ['/api/nfts/user'],
    enabled: !!isAuthenticated,
  });

  // Fetch user's activity
  const { data: activities, isLoading: isLoadingActivities } = useQuery<Activity[]>({
    queryKey: ['/api/activity'],
    enabled: !!isAuthenticated,
  });

  if (!isAuthenticated || !user) {
    return null;
  }

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const item = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0 },
  };

  return (
    <div className="min-h-screen flex flex-col bg-blue-50">
      <Header />
      
      <main className="flex-grow container mx-auto px-4 py-8">
        <motion.div
          variants={container}
          initial="hidden"
          animate="show"
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <StatsCard
            title="My Collection"
            value={`${nfts?.length || 0} NFTs`}
            icon={FaImages}
            change={{ value: 12.5, isPositive: true }}
            progress={70}
          />
          
          <StatsCard
            title="Total Value"
            value={formatEth(nfts?.length ? nfts.length * 0.52 : 0)}
            icon={FaCoins}
            change={{ value: 8.3, isPositive: true }}
            progress={65}
          />
          
          <StatsCard
            title="Minted This Month"
            value={`${nfts?.filter(nft => {
              const oneMonthAgo = new Date();
              oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1);
              return new Date(nft.mintedAt) > oneMonthAgo;
            }).length || 0} NFTs`}
            icon={FaFire}
            change={{ value: 4.2, isPositive: false }}
            progress={45}
          />
        </motion.div>
        
        <motion.div
          variants={item}
          className="bg-white rounded-xl shadow-md p-6 mb-8"
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">Recent Activity</h2>
            <Link href="/activity" className="text-primary hover:text-primary-600 text-sm font-medium">
              View All
            </Link>
          </div>
          
          <div className="overflow-x-auto">
            <table className="min-w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Event</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">NFT</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Value</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {isLoadingActivities ? (
                  <tr>
                    <td colSpan={5} className="px-4 py-4 text-center text-sm text-gray-500">
                      Loading activities...
                    </td>
                  </tr>
                ) : activities && activities.length > 0 ? (
                  activities.slice(0, 3).map((activity) => (
                    <tr key={activity.id}>
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-medium">
                        <div className="flex items-center">
                          <div className={`bg-${activity.action === 'mint' ? 'green' : 'blue'}-100 rounded-full p-2 mr-3`}>
                            <i className={`fas fa-${activity.action === 'mint' ? 'plus' : 'exchange-alt'} text-${activity.action === 'mint' ? 'green' : 'blue'}-600`}></i>
                          </div>
                          <span className="capitalize">{activity.action}</span>
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center">
                          {activity.nft && (
                            <>
                              <div className="h-8 w-8 rounded-md mr-2 bg-gray-200 overflow-hidden">
                                <img 
                                  src={activity.nft.imageUrl} 
                                  alt={activity.nft.name} 
                                  className="h-full w-full object-cover" 
                                />
                              </div>
                              <span>{activity.nft.name}</span>
                            </>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-500">
                        {formatDate(activity.timestamp)}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm font-mono">
                        0.52 ETH
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap text-sm">
                        <span className="px-2 py-1 text-xs rounded-full bg-green-100 text-green-800">
                          Completed
                        </span>
                      </td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan={5} className="px-4 py-4 text-center text-sm text-gray-500">
                      No activities found
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
        
        <motion.div variants={item}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">Your NFT Collection</h2>
            <Link href="/gallery" className="text-primary hover:text-primary-600 text-sm font-medium">
              View All
            </Link>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {isLoadingNfts ? (
              Array(4).fill(0).map((_, index) => (
                <div key={index} className="bg-white rounded-xl shadow-md h-64 animate-pulse">
                  <div className="h-48 bg-gray-200 rounded-t-xl"></div>
                  <div className="p-4">
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              ))
            ) : nfts && nfts.length > 0 ? (
              nfts.slice(0, 4).map((nft) => (
                <NFTCard key={nft.id} nft={nft} />
              ))
            ) : (
              <div className="col-span-full py-8 text-center">
                <p className="text-gray-500 mb-4">You don't have any NFTs yet</p>
                <Button asChild>
                  <Link href="/mint">Mint Your First NFT</Link>
                </Button>
              </div>
            )}
          </div>
        </motion.div>
      </main>
    </div>
  );
}
