import { Switch, Route } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "./lib/queryClient";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/hooks/use-auth";
import { MetamaskProvider } from "@/hooks/use-metamask";
import { GlobalAnimations } from "@/components/ui/animations";
import { AnimatedHeader } from "@/components/layout/animated-header";
import { Footer } from "@/components/layout/footer";

import Home from "@/pages/home";
import Login from "@/pages/login";
import Register from "@/pages/register";
import VerifyPending from "@/pages/verify-pending";
import Dashboard from "@/pages/dashboard";
import Mint from "@/pages/mint";
import Gallery from "@/pages/gallery";
import Profile from "@/pages/profile";
import Admin from "@/pages/admin";
import Verification from "@/pages/verification";
import ForgotPassword from "@/pages/forgot-password";
import ResetPassword from "@/pages/reset-password";
import LoadingDemo from "@/pages/loading-demo";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/verify-pending" component={VerifyPending} />
      <Route path="/dashboard" component={Dashboard} />
      <Route path="/mint" component={Mint} />
      <Route path="/gallery" component={Gallery} />
      <Route path="/profile" component={Profile} />
      <Route path="/admin" component={Admin} />
      <Route path="/verification" component={Verification} />
      <Route path="/forgot-password" component={ForgotPassword} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/loading-demo" component={LoadingDemo} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <MetamaskProvider>
          <GlobalAnimations />
          <AnimatedHeader />
          <div className="pt-16 min-h-screen">
            <Router />
          </div>
          <Footer />
          <Toaster />
        </MetamaskProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
