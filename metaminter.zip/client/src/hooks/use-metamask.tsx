import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { apiRequest } from '@/lib/queryClient';

interface MetamaskContextType {
  isInstalled: boolean;
  account: string | null;
  isConnecting: boolean;
  isConnected: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  mintNFT: () => Promise<boolean>;
  buyNFT: (nftId: number, price: string) => Promise<boolean>;
}

declare global {
  interface Window {
    ethereum?: {
      isMetaMask?: boolean;
      request: (request: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, callback: (...args: any[]) => void) => void;
      removeListener: (event: string, callback: (...args: any[]) => void) => void;
    };
  }
}

const MetamaskContext = createContext<MetamaskContextType | undefined>(undefined);

export const MetamaskProvider = ({ children }: { children: ReactNode }) => {
  const [isInstalled, setIsInstalled] = useState<boolean>(false);
  const [account, setAccount] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState<boolean>(false);
  const { toast } = useToast();
  const { user, updateProfile } = useAuth();

  useEffect(() => {
    const checkIfMetaMaskIsInstalled = () => {
      const { ethereum } = window;
      if (ethereum && ethereum.isMetaMask) {
        setIsInstalled(true);
        
        // Check if already connected
        ethereum.request({ method: 'eth_accounts' })
          .then(handleAccountsChanged)
          .catch((err: Error) => {
            console.error(err);
          });
      } else {
        setIsInstalled(false);
      }
    };

    checkIfMetaMaskIsInstalled();
  }, []);

  const handleAccountsChanged = (accounts: string[]) => {
    if (accounts.length === 0) {
      setAccount(null);
    } else {
      setAccount(accounts[0]);
      
      // If connected wallet is different from stored wallet, update profile
      if (user && user.walletAddress !== accounts[0]) {
        updateProfile({ walletAddress: accounts[0] })
          .catch(console.error);
      }
    }
  };

  useEffect(() => {
    if (isInstalled) {
      // Listen for account changes
      const accountsChangedHandler = (accounts: string[]) => {
        handleAccountsChanged(accounts);
      };
      
      window.ethereum?.on('accountsChanged', accountsChangedHandler);
      
      return () => {
        window.ethereum?.removeListener('accountsChanged', accountsChangedHandler);
      };
    }
  }, [isInstalled, user]);

  const connectWallet = async () => {
    if (!isInstalled) {
      toast({
        title: 'MetaMask is not installed',
        description: 'Please install MetaMask to connect your wallet',
        variant: 'destructive',
      });
      return;
    }

    try {
      setIsConnecting(true);
      const accounts = await window.ethereum!.request({
        method: 'eth_requestAccounts',
      });
      handleAccountsChanged(accounts);
      
      toast({
        title: 'Wallet connected',
        description: 'Your MetaMask wallet has been connected successfully',
      });
    } catch (err: any) {
      toast({
        title: 'Failed to connect wallet',
        description: err.message || 'An unknown error occurred',
        variant: 'destructive',
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setAccount(null);
    if (user && user.walletAddress) {
      updateProfile({ walletAddress: '' })
        .catch(console.error);
    }
    toast({
      title: 'Wallet disconnected',
      description: 'Your MetaMask wallet has been disconnected',
    });
  };

  const mintNFT = async (): Promise<boolean> => {
    if (!isInstalled || !account) {
      toast({
        title: 'Wallet not connected',
        description: 'Please connect your MetaMask wallet to mint NFTs',
        variant: 'destructive',
      });
      return false;
    }

    try {
      // Fixed price of 0.52 ETH converted to Wei (1 ETH = 10^18 Wei)
      const FIXED_PRICE_ETH = 0.52;
      const priceInWei = `0x${(FIXED_PRICE_ETH * 1e18).toString(16)}`;
      
      // Owner's Ethereum wallet address - all payments go to this address
      // Replace this with your own wallet address
      const OWNER_WALLET = '0x1234567890123456789012345678901234567890'; // Your Ethereum wallet address
      
      // Show confirmation modal for transparency
      toast({
        title: 'Confirm Transaction',
        description: `You're about to send ${FIXED_PRICE_ETH} ETH to mint your NFT`,
      });
      
      // Send transaction
      const txHash = await window.ethereum!.request({
        method: 'eth_sendTransaction',
        params: [{
          from: account,
          to: OWNER_WALLET,
          value: priceInWei,
          // Optional data field for transaction metadata
          data: '0x', // Empty data for a standard ETH transfer
        }],
      });
      
      // Record the transaction
      await apiRequest('POST', '/api/activity', {
        type: 'mint',
        nftId: null, // This would be set after the NFT is created
        description: `Minted NFT for ${FIXED_PRICE_ETH} ETH`,
        transactionHash: txHash,
      });
      
      toast({
        title: 'NFT Minted Successfully',
        description: 'Your transaction has been submitted and is being processed',
      });
      
      return true;
    } catch (err: any) {
      console.error('Minting error:', err);
      toast({
        title: 'Minting Failed',
        description: err.message || 'Failed to mint NFT',
        variant: 'destructive',
      });
      return false;
    }
  };

  // Buy an existing NFT - payment goes to owner's wallet
  const buyNFT = async (nftId: number, price: string): Promise<boolean> => {
    if (!isInstalled || !account) {
      toast({
        title: 'Wallet not connected',
        description: 'Please connect your MetaMask wallet to purchase NFTs',
        variant: 'destructive',
      });
      return false;
    }

    try {
      // Parse the price from ETH to Wei (1 ETH = 10^18 Wei)
      const priceInETH = parseFloat(price);
      const priceInWei = `0x${(priceInETH * 1e18).toString(16)}`;
      
      // Owner's Ethereum wallet address - same as the minting destination
      // All payments go to this address
      const OWNER_WALLET = '0x1234567890123456789012345678901234567890'; // Your Ethereum wallet address
      
      // Show confirmation modal for transparency
      toast({
        title: 'Confirm Purchase',
        description: `You're about to send ${priceInETH} ETH to purchase this NFT`,
      });
      
      // Send transaction
      const txHash = await window.ethereum!.request({
        method: 'eth_sendTransaction',
        params: [{
          from: account,
          to: OWNER_WALLET,
          value: priceInWei,
          // Optional data field for transaction metadata
          data: '0x', // Empty data for a standard ETH transfer
        }],
      });
      
      // Record the transaction
      await apiRequest('POST', '/api/activity', {
        type: 'purchase',
        nftId: nftId,
        description: `Purchased NFT #${nftId} for ${priceInETH} ETH`,
        transactionHash: txHash,
      });
      
      // Update the NFT ownership
      await apiRequest('POST', `/api/nfts/${nftId}/transfer`, {
        newOwnerId: user?.id,
        transactionHash: txHash
      });
      
      toast({
        title: 'NFT Purchased Successfully',
        description: 'Your transaction has been submitted and is being processed',
      });
      
      return true;
    } catch (err: any) {
      console.error('Purchase error:', err);
      toast({
        title: 'Purchase Failed',
        description: err.message || 'Failed to purchase NFT',
        variant: 'destructive',
      });
      return false;
    }
  };

  return (
    <MetamaskContext.Provider
      value={{
        isInstalled,
        account,
        isConnecting,
        isConnected: !!account,
        connectWallet,
        disconnectWallet,
        mintNFT,
        buyNFT,
      }}
    >
      {children}
    </MetamaskContext.Provider>
  );
};

export const useMetamask = () => {
  const context = useContext(MetamaskContext);
  if (context === undefined) {
    throw new Error('useMetamask must be used within a MetamaskProvider');
  }
  return context;
};
