import { useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useAuth } from '@/hooks/use-auth';
import { useMetamask } from '@/hooks/use-metamask';
import { truncateAddress } from '@/lib/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { FaCubes, FaWallet, FaBell, FaBars, FaTimes } from 'react-icons/fa';

export function Header() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();
  const { isConnected, account, connectWallet, disconnectWallet } = useMetamask();

  const menuItems = [
    { label: 'Dashboard', path: '/dashboard' },
    { label: 'Mint NFT', path: '/mint' },
    { label: 'Gallery', path: '/gallery' },
    { label: 'Profile', path: '/profile' },
  ];
  
  if (user?.isAdmin) {
    menuItems.push({ label: 'Admin', path: '/admin' });
  }

  return (
    <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
      <div className="container mx-auto px-4 py-3 flex items-center justify-between">
        <div className="flex items-center">
          <Link href={isAuthenticated ? '/dashboard' : '/'} className="flex items-center">
            <FaCubes className="text-primary text-2xl mr-2" />
            <span className="text-xl font-bold text-primary">NFTMint</span>
          </Link>
          
          {isAuthenticated && (
            <nav className="hidden md:flex ml-8">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`px-3 py-2 ${
                    location === item.path
                      ? 'text-primary font-medium'
                      : 'text-gray-700 hover:text-primary font-medium'
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>
          )}
        </div>
        
        {isAuthenticated ? (
          <div className="flex items-center">
            <Button
              variant={isConnected ? "outline" : "default"}
              size="sm"
              className="mr-4 hidden sm:flex"
              onClick={isConnected ? disconnectWallet : connectWallet}
            >
              <FaWallet className="mr-2" />
              {isConnected 
                ? truncateAddress(account || '') 
                : "Connect Wallet"}
            </Button>
            
            <div className="relative mr-4">
              <Button variant="ghost" size="icon" className="relative">
                <FaBell />
                <span className="absolute top-0 right-0 block h-4 w-4 rounded-full bg-red-500 text-xs text-white font-bold flex items-center justify-center">
                  {user?.isAdmin ? 3 : 0}
                </span>
              </Button>
            </div>
            
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center">
                  <div className="h-8 w-8 rounded-full bg-gray-300 overflow-hidden mr-2">
                    {/* Placeholder avatar */}
                    <svg className="h-full w-full text-gray-500" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M24 20.993V24H0v-2.996A14.977 14.977 0 0112.004 15c4.904 0 9.26 2.354 11.996 5.993zM16.002 8.999a4 4 0 11-8 0 4 4 0 018 0z" />
                    </svg>
                  </div>
                  <span className="hidden md:block">
                    {user?.username || 'User'}
                  </span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem asChild>
                  <Link href="/profile">Your Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => logout()}>
                  Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button 
              variant="ghost" 
              size="icon"
              className="md:hidden ml-2"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            >
              {isMobileMenuOpen ? <FaTimes /> : <FaBars />}
            </Button>
          </div>
        ) : (
          <div className="flex items-center space-x-4">
            <Button asChild variant="outline">
              <Link href="/login">Login</Link>
            </Button>
            <Button asChild className="hidden sm:inline-flex">
              <Link href="/register">Register</Link>
            </Button>
          </div>
        )}
      </div>
      
      {/* Mobile menu */}
      <AnimatePresence>
        {isMobileMenuOpen && isAuthenticated && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="md:hidden border-t border-gray-200 overflow-hidden"
          >
            <div className="px-2 pt-2 pb-3 space-y-1">
              {menuItems.map((item) => (
                <Link
                  key={item.path}
                  href={item.path}
                  className={`block px-3 py-2 rounded-md text-base font-medium ${
                    location === item.path
                      ? 'text-primary bg-primary-50'
                      : 'text-gray-700 hover:text-primary hover:bg-primary-50'
                  }`}
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.label}
                </Link>
              ))}
              <Button
                variant={isConnected ? "outline" : "default"}
                size="sm"
                className="mt-2 w-full"
                onClick={isConnected ? disconnectWallet : connectWallet}
              >
                <FaWallet className="mr-2" />
                {isConnected 
                  ? truncateAddress(account || '') 
                  : "Connect Wallet"}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
