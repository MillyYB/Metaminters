import { motion } from "framer-motion";
import { FaEnvelope, FaGithub, FaTwitter, FaDiscord, FaEthereum } from "react-icons/fa";
import { Link } from "wouter";

export function Footer() {
  const contactEmail = "emilianarokash22@gmail.com";
  
  const fadeInVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.5,
        ease: "easeOut"
      }
    }
  };

  const socialLinkVariants = {
    hover: { 
      scale: 1.1, 
      color: "#ef4444",
      transition: { duration: 0.2 }
    },
    tap: { scale: 0.95 }
  };
  
  return (
    <motion.footer
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      className="bg-gray-900 border-t border-red-500/20 py-12 mt-16"
    >
      <div className="container px-4 mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <motion.div 
            variants={fadeInVariants}
            className="col-span-1 md:col-span-2"
          >
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2, duration: 0.4 }}
              className="flex items-center mb-4"
            >
              <FaEthereum className="text-red-500 text-3xl mr-2 animate-pulse" />
              <h2 className="text-2xl font-bold text-white">MetaMinter</h2>
            </motion.div>
            <p className="text-gray-400 mb-4">
              The premier NFT marketplace for exclusive digital collectibles. Mint, buy, and sell unique digital assets on the Ethereum blockchain.
            </p>
            <div className="flex items-center space-x-4 mt-6">
              <motion.a 
                href={`mailto:${contactEmail}`}
                variants={socialLinkVariants}
                whileHover="hover"
                whileTap="tap"
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <FaEnvelope className="text-xl" />
              </motion.a>
              <motion.a 
                href="#"
                variants={socialLinkVariants}
                whileHover="hover"
                whileTap="tap"
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <FaTwitter className="text-xl" />
              </motion.a>
              <motion.a 
                href="#"
                variants={socialLinkVariants}
                whileHover="hover"
                whileTap="tap"
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <FaDiscord className="text-xl" />
              </motion.a>
              <motion.a 
                href="#"
                variants={socialLinkVariants}
                whileHover="hover"
                whileTap="tap"
                className="text-gray-400 hover:text-red-500 transition-colors"
              >
                <FaGithub className="text-xl" />
              </motion.a>
            </div>
          </motion.div>
          
          <motion.div variants={fadeInVariants} custom={1}>
            <h3 className="text-lg font-semibold text-white mb-4">Marketplace</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/gallery" className="text-gray-400 hover:text-red-500 transition-colors">
                  Explore
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-red-500 transition-colors">
                  Top Collections
                </Link>
              </li>
              <li>
                <Link href="#" className="text-gray-400 hover:text-red-500 transition-colors">
                  Featured Artists
                </Link>
              </li>
              <li>
                <Link href="/mint" className="text-gray-400 hover:text-red-500 transition-colors">
                  Create NFT
                </Link>
              </li>
            </ul>
          </motion.div>
          
          <motion.div variants={fadeInVariants} custom={2}>
            <h3 className="text-lg font-semibold text-white mb-4">Contact</h3>
            <p className="text-gray-400 mb-2">
              Have questions or need support?
            </p>
            <a 
              href={`mailto:${contactEmail}`}
              className="flex items-center text-red-500 hover:text-red-400 transition-colors font-medium"
            >
              <FaEnvelope className="mr-2" />
              {contactEmail}
            </a>
            <p className="text-gray-400 mt-4">
              Response time: Within 24 hours
            </p>
          </motion.div>
        </div>
        
        <motion.div 
          variants={fadeInVariants}
          className="border-t border-red-500/10 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center"
        >
          <p className="text-gray-500 text-sm">
            © {new Date().getFullYear()} MetaMinter. All rights reserved.
          </p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="#" className="text-gray-400 text-sm hover:text-red-500 transition-colors">
              Terms of Service
            </Link>
            <Link href="#" className="text-gray-400 text-sm hover:text-red-500 transition-colors">
              Privacy Policy
            </Link>
          </div>
        </motion.div>
      </div>
    </motion.footer>
  );
}