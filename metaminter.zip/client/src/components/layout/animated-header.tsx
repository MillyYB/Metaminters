import { useState, useEffect } from 'react';
import { Link, useLocation } from 'wouter';
import { useAuth } from '@/hooks/use-auth';
import { AnimatedLoader } from '@/components/ui/animated-loader';
import { VerificationBadge } from '@/components/ui/verification-badge';
import { FaEthereum, FaUserCircle, FaBars, FaTimes } from 'react-icons/fa';
import { motion, AnimatePresence } from 'framer-motion';

export function AnimatedHeader() {
  const [location] = useLocation();
  const { user, isAuthenticated, logout } = useAuth();
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', href: '/' },
    { label: 'Dashboard', href: '/dashboard' },
    { label: 'Gallery', href: '/gallery' },
    { label: 'Mint', href: '/mint' },
    { label: 'Verification', href: '/verification' },
  ];

  const isActive = (path: string) => {
    if (path === '/' && location !== '/') return false;
    return location === path || location.startsWith(path + '/');
  };

  return (
    <header 
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        isScrolled 
          ? 'bg-black border-b border-red-500/30 shadow-lg shadow-red-900/10' 
          : 'bg-black/80 backdrop-blur-sm'
      }`}
    >
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link href="/">
            <a className="flex items-center space-x-2">
              <FaEthereum className="text-red-500 text-2xl animate-float" />
              <span className="text-white font-bold text-xl">
                <span className="text-red-500">Meta</span>Minter
              </span>
            </a>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            {navItems.map((item, index) => (
              <Link key={item.href} href={item.href}>
                <a 
                  className={`relative px-1 py-2 text-sm font-medium transition-colors ${
                    isActive(item.href) 
                      ? 'text-red-500' 
                      : 'text-gray-300 hover:text-white'
                  }`}
                >
                  {item.label}
                  {isActive(item.href) && (
                    <motion.div 
                      layoutId="nav-indicator"
                      className="absolute bottom-0 left-0 w-full h-0.5 bg-red-500"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 0.3 }}
                    />
                  )}
                </a>
              </Link>
            ))}
          </nav>

          {/* User & Verification Badge */}
          <div className="flex items-center space-x-4">
            <VerificationBadge className="hidden md:block" />
            
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <Link href="/profile">
                  <a className="flex items-center text-gray-300 hover:text-white">
                    <div className="w-8 h-8 rounded-full bg-gray-800 border border-red-500/30 flex items-center justify-center">
                      <FaUserCircle className="text-red-500" />
                    </div>
                    <span className="ml-2 hidden lg:inline font-medium">{user?.firstName || user?.username}</span>
                  </a>
                </Link>
                <button 
                  onClick={() => logout()}
                  className="text-sm bg-red-500/10 text-red-500 px-3 py-1.5 rounded border border-red-500/30 hover:bg-red-500/20 transition-colors"
                >
                  Logout
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <Link href="/login">
                  <a className="text-sm text-white hover:text-red-400 transition-colors">
                    Login
                  </a>
                </Link>
                <Link href="/register">
                  <a className="text-sm bg-red-600 text-white px-3 py-1.5 rounded hover:bg-red-700 transition-colors">
                    Register
                  </a>
                </Link>
              </div>
            )}

            {/* Mobile menu button */}
            <button 
              className="md:hidden bg-gray-800 p-2 rounded-md"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <FaTimes className="text-red-500" />
              ) : (
                <FaBars className="text-red-500" />
              )}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile navigation */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div 
            className="md:hidden bg-gray-900 border-t border-red-500/30"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
          >
            <div className="container mx-auto px-4 py-3">
              <nav className="flex flex-col space-y-3">
                {navItems.map((item) => (
                  <Link key={item.href} href={item.href}>
                    <a 
                      className={`px-2 py-2 text-sm font-medium transition-colors ${
                        isActive(item.href)
                          ? 'text-red-500 bg-red-500/10 rounded'
                          : 'text-gray-300 hover:text-white'
                      }`}
                      onClick={() => setMobileMenuOpen(false)}
                    >
                      {item.label}
                    </a>
                  </Link>
                ))}
                <VerificationBadge className="my-2" />
              </nav>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}