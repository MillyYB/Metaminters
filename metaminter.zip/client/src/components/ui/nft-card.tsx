import { useState } from 'react';
import { motion } from 'framer-motion';
import { formatDate, formatEth } from '@/lib/utils';
import { NFT } from '@shared/schema';
import { FaEthereum, FaHeart, FaUser } from 'react-icons/fa';
import { useMetamask } from '@/hooks/use-metamask';
import { LoadingButton } from '@/components/ui/loading-states';

// Extended NFT type with additional display properties
interface NFTDisplayProps extends NFT {
  creatorName?: string;
}

interface NFTCardProps {
  nft: NFTDisplayProps;
  className?: string;
  onClick?: () => void;
  onPurchase?: (nft: NFTDisplayProps) => Promise<void>;
  isPurchasing?: boolean;
  showPurchaseButton?: boolean;
}

export function NFTCard({ 
  nft, 
  className, 
  onClick, 
  onPurchase, 
  isPurchasing = false, 
  showPurchaseButton = true 
}: NFTCardProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [isFavorite, setIsFavorite] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const { isConnected } = useMetamask();

  const toggleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsFavorite(!isFavorite);
  };

  const handlePurchase = async (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!nft.id || !onPurchase) return;
    
    setIsProcessing(true);
    try {
      await onPurchase(nft);
    } finally {
      setIsProcessing(false);
    }
  };
  
  // Safe formatting for dates that might be null
  const formatMintDate = (date: Date | null) => {
    if (!date) return 'N/A';
    return formatDate(date);
  };

  // Framer Motion variants for animations
  const cardVariants = {
    initial: { opacity: 0, y: 20 },
    animate: { 
      opacity: 1, 
      y: 0,
      transition: { 
        duration: 0.4,
        ease: "easeOut"
      }
    },
    hover: { 
      y: -10,
      boxShadow: "0 20px 25px -5px rgba(239, 68, 68, 0.3), 0 10px 10px -5px rgba(239, 68, 68, 0.2)",
      transition: { 
        duration: 0.2,
        ease: "easeOut"
      }
    }
  };

  const imageVariants = {
    hover: { 
      scale: 1.1,
      transition: { duration: 0.5 }
    }
  };

  const badgeVariants = {
    initial: { opacity: 0, x: -20 },
    animate: { 
      opacity: 1, 
      x: 0,
      transition: { delay: 0.2, duration: 0.3 }
    }
  };

  const priceVariants = {
    initial: { opacity: 0, scale: 0.8 },
    animate: { 
      opacity: 1, 
      scale: 1,
      transition: { 
        delay: 0.3, 
        duration: 0.3,
        type: "spring",
        stiffness: 300
      }
    },
    hover: {
      scale: 1.05
    }
  };

  return (
    <motion.div
      variants={cardVariants}
      initial="initial"
      animate="animate"
      whileHover="hover"
      className={`group nft-card ${className}`}
      onClick={onClick}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <div className="bg-gray-900 border border-red-500/30 rounded-xl overflow-hidden shadow-lg transition-all duration-300 cursor-pointer h-full">
        <div className="relative bg-black h-64 overflow-hidden">
          {nft.imageUrl && (
            <>
              <motion.img
                variants={imageVariants}
                src={nft.imageUrl}
                alt={nft.name}
                className={`h-64 w-full object-cover transition-all duration-500 ${
                  isLoaded ? 'opacity-100' : 'opacity-0'
                }`}
                onLoad={() => setIsLoaded(true)}
              />
              {!isLoaded && (
                <div className="absolute inset-0 bg-gray-800 animate-pulse" />
              )}
            </>
          )}
          
          {/* NFT Token ID badge */}
          <motion.div 
            variants={badgeVariants}
            className="absolute top-3 left-3 bg-red-500 bg-opacity-80 backdrop-blur-sm rounded-lg px-2 py-1 animate-glow"
          >
            <span className="text-white text-xs font-mono font-bold">#{nft.id}</span>
          </motion.div>
          
          {/* Like button */}
          <motion.button 
            className="absolute top-3 right-3 w-8 h-8 rounded-full bg-black bg-opacity-70 backdrop-blur-sm flex items-center justify-center hover:bg-red-900/50 border border-red-500/50 transition-all duration-200"
            onClick={toggleFavorite}
            whileTap={{ scale: 0.85 }}
            whileHover={{ scale: 1.1 }}
          >
            <FaHeart 
              className={`text-sm transition-colors duration-300 ${isFavorite ? 'text-red-500' : 'text-gray-400'}`} 
            />
          </motion.button>
          
          {/* Quick actions panel that shows on hover */}
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={isHovered ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
            transition={{ duration: 0.2 }}
            className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/90 to-transparent p-4"
          >
            <div className="flex justify-between items-center">
              <motion.button 
                whileHover={{ scale: 1.05, backgroundColor: "rgba(239, 68, 68, 0.2)" }}
                whileTap={{ scale: 0.95 }}
                className="text-white text-sm bg-gray-800/80 backdrop-blur-sm px-3 py-1 rounded-full border border-red-500/30 transition-colors btn-hover-effect"
              >
                View Details
              </motion.button>
              {showPurchaseButton && (
                isPurchasing || isProcessing ? (
                  <LoadingButton
                    isLoading={true}
                    loadingText="Buying..."
                    spinnerVariant="ethereum"
                    className="text-white text-sm bg-red-600 px-3 py-1 rounded-full"
                    disabled
                  >
                    Buy Now
                  </LoadingButton>
                ) : (
                  <motion.button 
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="text-white text-sm bg-red-600 px-3 py-1 rounded-full hover:bg-red-700 transition-colors btn-hover-effect"
                    onClick={handlePurchase}
                    disabled={!isConnected || !onPurchase}
                  >
                    {isConnected ? "Buy Now" : "Connect Wallet"}
                  </motion.button>
                )
              )}
            </div>
          </motion.div>
        </div>
        
        <div className="p-4">
          <div className="flex justify-between items-start mb-2">
            <motion.h3 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
              className="font-bold text-white truncate"
            >
              {nft.name}
            </motion.h3>
            <motion.div 
              variants={priceVariants}
              className="flex items-center bg-black rounded-full px-2 py-1 border border-red-500/50"
            >
              <FaEthereum className="text-red-500 mr-1 text-xs animate-pulse" />
              <span className="font-mono text-xs font-bold text-red-400">{formatEth(nft.price || '0.52')}</span>
            </motion.div>
          </div>
          
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="flex items-center justify-between text-sm"
          >
            <div className="flex items-center">
              <motion.div 
                whileHover={{ scale: 1.1, borderColor: "rgba(239, 68, 68, 0.5)" }}
                className="w-5 h-5 rounded-full bg-red-500/20 border border-red-500/30 flex items-center justify-center mr-1.5"
              >
                <span className="text-red-400 text-xs font-bold">
                  {nft.creatorName?.charAt(0) || <FaUser className="text-xs" />}
                </span>
              </motion.div>
              <span className="text-gray-400 truncate">
                {nft.creatorName || 'Artist'}
              </span>
            </div>
            <span className="text-gray-500 text-xs">
              {nft.lastSoldAt ? 
                `Last Sold: ${formatDate(nft.lastSoldAt)}` : 
                `Minted: ${formatMintDate(nft.mintedAt)}`
              }
            </span>
          </motion.div>
        </div>
      </div>
    </motion.div>
  );
}
