import { FaEthereum } from "react-icons/fa";
import { cn } from "@/lib/utils";

interface AnimatedLoaderProps {
  className?: string;
  size?: "sm" | "md" | "lg";
  showEth?: boolean;
}

export function AnimatedLoader({ 
  className, 
  size = "md", 
  showEth = true 
}: AnimatedLoaderProps) {
  const sizeClasses = {
    sm: "w-5 h-5",
    md: "w-8 h-8",
    lg: "w-12 h-12"
  };

  return (
    <div className={cn("flex flex-col items-center justify-center", className)}>
      <div className="relative">
        {showEth && (
          <div className="absolute inset-0 flex items-center justify-center animate-bounce text-red-500 z-10">
            <FaEthereum size={size === "sm" ? 12 : size === "md" ? 20 : 28} />
          </div>
        )}
        <div 
          className={cn(
            "border-4 border-t-red-500 border-r-gray-800 border-b-red-500 border-l-gray-800 rounded-full animate-spin",
            sizeClasses[size]
          )}
        />
      </div>
    </div>
  );
}

// Add more animations for the website
const style = document.createElement('style');
style.textContent = `
  @keyframes pulse-red {
    0%, 100% { box-shadow: 0 0 0 0 rgba(255, 0, 0, 0.4); }
    50% { box-shadow: 0 0 0 10px rgba(255, 0, 0, 0); }
  }
  
  .animate-pulse-red {
    animation: pulse-red 2s infinite;
  }
  
  @keyframes slide-in-right {
    0% { transform: translateX(100%); opacity: 0; }
    100% { transform: translateX(0); opacity: 1; }
  }
  
  .animate-slide-in-right {
    animation: slide-in-right 0.5s ease-out forwards;
  }

  @keyframes slide-in-left {
    0% { transform: translateX(-100%); opacity: 0; }
    100% { transform: translateX(0); opacity: 1; }
  }
  
  .animate-slide-in-left {
    animation: slide-in-left 0.5s ease-out forwards;
  }

  @keyframes fade-in-up {
    0% { transform: translateY(20px); opacity: 0; }
    100% { transform: translateY(0); opacity: 1; }
  }
  
  .animate-fade-in-up {
    animation: fade-in-up 0.5s ease-out forwards;
  }
`;
document.head.appendChild(style);