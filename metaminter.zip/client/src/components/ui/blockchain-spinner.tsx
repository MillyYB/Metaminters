import React from 'react';
import { motion } from 'framer-motion';
import { FaEthereum, FaCube, FaLink } from 'react-icons/fa';

type SpinnerSize = 'sm' | 'md' | 'lg' | 'xl';
type SpinnerVariant = 'ethereum' | 'chain' | 'blocks' | 'nodes';

interface BlockchainSpinnerProps {
  size?: SpinnerSize;
  variant?: SpinnerVariant;
  text?: string;
  className?: string;
}

export function BlockchainSpinner({ 
  size = 'md', 
  variant = 'ethereum',
  text,
  className = ''
}: BlockchainSpinnerProps) {
  // Size mapping
  const sizeMap: Record<SpinnerSize, string> = {
    sm: 'w-8 h-8',
    md: 'w-12 h-12',
    lg: 'w-16 h-16',
    xl: 'w-24 h-24'
  };

  // Text size mapping
  const textSizeMap: Record<SpinnerSize, string> = {
    sm: 'text-xs',
    md: 'text-sm',
    lg: 'text-base',
    xl: 'text-lg'
  };

  // Ethereum Spinner
  if (variant === 'ethereum') {
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <div className={`relative ${sizeMap[size]}`}>
          <motion.div
            className="absolute inset-0 rounded-full border-2 border-red-500/30"
            animate={{ 
              rotate: 360,
              boxShadow: ["0 0 5px rgba(239, 68, 68, 0.3)", "0 0 15px rgba(239, 68, 68, 0.6)", "0 0 5px rgba(239, 68, 68, 0.3)"]
            }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
          <motion.div 
            className="absolute inset-0 flex items-center justify-center text-red-500"
            animate={{ 
              scale: [1, 1.1, 1],
              opacity: [0.7, 1, 0.7]
            }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <FaEthereum className={size === 'sm' ? 'text-lg' : size === 'md' ? 'text-2xl' : size === 'lg' ? 'text-3xl' : 'text-4xl'} />
          </motion.div>
        </div>
        {text && <p className={`mt-2 text-gray-300 ${textSizeMap[size]}`}>{text}</p>}
      </div>
    );
  }

  // Chain Spinner
  if (variant === 'chain') {
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <div className={`relative ${sizeMap[size]}`}>
          <motion.div 
            className="absolute inset-0 flex items-center justify-center"
            animate={{ rotate: 360 }}
            transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
          >
            <div className="absolute w-full h-full border-4 border-dashed rounded-full border-red-500/30" />
          </motion.div>
          
          <motion.div 
            className="absolute inset-0 flex items-center justify-center"
            animate={{ rotate: -180 }}
            transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
          >
            <div className="absolute w-3/4 h-3/4 border-4 border-dashed rounded-full border-red-500/50" />
          </motion.div>
          
          <motion.div 
            className="absolute inset-0 flex items-center justify-center"
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 2, repeat: Infinity, ease: "easeInOut" }}
          >
            <FaLink className={`text-red-500 ${size === 'sm' ? 'text-lg' : size === 'md' ? 'text-2xl' : size === 'lg' ? 'text-3xl' : 'text-4xl'}`} />
          </motion.div>
        </div>
        {text && <p className={`mt-2 text-gray-300 ${textSizeMap[size]}`}>{text}</p>}
      </div>
    );
  }

  // Blocks Spinner
  if (variant === 'blocks') {
    const blockSize = size === 'sm' ? 'w-1.5 h-1.5' : size === 'md' ? 'w-2 h-2' : size === 'lg' ? 'w-3 h-3' : 'w-4 h-4';
    const gap = size === 'sm' ? 'gap-1' : size === 'md' ? 'gap-1.5' : size === 'lg' ? 'gap-2' : 'gap-3';
    
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <div className={`grid grid-cols-3 ${gap} ${sizeMap[size]}`}>
          {[...Array(9)].map((_, index) => (
            <motion.div
              key={index}
              className={`${blockSize} bg-red-500 rounded-sm`}
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.4, 1, 0.4],
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "easeInOut",
                delay: index * 0.1
              }}
            />
          ))}
        </div>
        {text && <p className={`mt-3 text-gray-300 ${textSizeMap[size]}`}>{text}</p>}
      </div>
    );
  }

  // Nodes Spinner
  if (variant === 'nodes') {
    const nodeSize = size === 'sm' ? 'w-1.5 h-1.5' : size === 'md' ? 'w-2 h-2' : size === 'lg' ? 'w-2.5 h-2.5' : 'w-3 h-3';
    const containerSize = size === 'sm' ? 'w-8 h-8' : size === 'md' ? 'w-12 h-12' : size === 'lg' ? 'w-16 h-16' : 'w-20 h-20';
    
    // Generate 12 nodes in a circle
    const nodes = Array.from({ length: 12 }).map((_, i) => {
      const angle = (i / 12) * Math.PI * 2;
      const radius = size === 'sm' ? 3 : size === 'md' ? 4.5 : size === 'lg' ? 6 : 8;
      
      return {
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
        delay: i * 0.1
      };
    });
    
    return (
      <div className={`flex flex-col items-center justify-center ${className}`}>
        <div className={`relative ${containerSize}`}>
          <motion.div
            className="absolute inset-0 rounded-full border border-red-500/30"
            animate={{ rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          />
          
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="relative w-full h-full">
              {nodes.map((node, index) => (
                <motion.div
                  key={index}
                  className={`absolute ${nodeSize} bg-red-500 rounded-full`}
                  style={{
                    left: `calc(50% + ${node.x}rem)`,
                    top: `calc(50% + ${node.y}rem)`,
                    translateX: "-50%",
                    translateY: "-50%"
                  }}
                  animate={{
                    scale: [1, 1.5, 1],
                    opacity: [0.4, 1, 0.4],
                    boxShadow: ["0 0 0px rgba(239, 68, 68, 0)", "0 0 8px rgba(239, 68, 68, 0.8)", "0 0 0px rgba(239, 68, 68, 0)"]
                  }}
                  transition={{
                    duration: 2,
                    repeat: Infinity,
                    ease: "easeInOut",
                    delay: node.delay
                  }}
                />
              ))}
              
              <motion.div 
                className="absolute left-1/2 top-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-red-500 rounded-full"
                style={{
                  width: size === 'sm' ? "0.5rem" : size === 'md' ? "0.75rem" : size === 'lg' ? "1rem" : "1.25rem",
                  height: size === 'sm' ? "0.5rem" : size === 'md' ? "0.75rem" : size === 'lg' ? "1rem" : "1.25rem"
                }}
                animate={{
                  scale: [1, 1.2, 1],
                  opacity: [0.7, 1, 0.7]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                }}
              />
            </div>
          </div>
        </div>
        {text && <p className={`mt-3 text-gray-300 ${textSizeMap[size]}`}>{text}</p>}
      </div>
    );
  }

  // Default fallback
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <motion.div
        className={`${sizeMap[size]} border-t-2 border-red-500 rounded-full`}
        animate={{ rotate: 360 }}
        transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
      />
      {text && <p className={`ml-3 text-gray-300 ${textSizeMap[size]}`}>{text}</p>}
    </div>
  );
}