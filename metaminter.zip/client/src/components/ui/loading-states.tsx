import React from 'react';
import { motion } from 'framer-motion';
import { BlockchainSpinner } from './blockchain-spinner';

interface LoadingStateProps {
  type?: 'fullscreen' | 'inline' | 'overlay' | 'button';
  text?: string;
  variant?: 'ethereum' | 'chain' | 'blocks' | 'nodes';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export function LoadingState({ 
  type = 'inline', 
  text, 
  variant = 'ethereum',
  size = 'md',
  className = ''
}: LoadingStateProps) {
  
  // Fullscreen loading state that covers the entire viewport
  if (type === 'fullscreen') {
    return (
      <motion.div 
        className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-col items-center justify-center">
          <BlockchainSpinner 
            variant={variant} 
            size="xl" 
            text={text || "Loading..."} 
          />
          <motion.div 
            className="w-48 h-1.5 bg-gray-800 rounded-full mt-6 overflow-hidden"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
          >
            <motion.div 
              className="h-full bg-gradient-to-r from-red-700 via-red-500 to-red-700 rounded-full"
              animate={{ 
                x: ["-100%", "100%"],
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                ease: "easeInOut"
              }}
            />
          </motion.div>
        </div>
      </motion.div>
    );
  }
  
  // Overlay loading state that covers a specific element
  if (type === 'overlay') {
    return (
      <motion.div 
        className={`absolute inset-0 bg-black/70 backdrop-blur-[2px] rounded-lg flex items-center justify-center z-10 ${className}`}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
      >
        <BlockchainSpinner 
          variant={variant} 
          size={size} 
          text={text} 
        />
      </motion.div>
    );
  }
  
  // Button loading state for inside buttons
  if (type === 'button') {
    return (
      <div className={`flex items-center justify-center ${className}`}>
        <BlockchainSpinner 
          variant={variant} 
          size="sm" 
        />
        {text && <span className="ml-2">{text}</span>}
      </div>
    );
  }
  
  // Default inline loading state
  return (
    <div className={`flex items-center justify-center py-4 ${className}`}>
      <BlockchainSpinner 
        variant={variant} 
        size={size} 
        text={text} 
      />
    </div>
  );
}

// LoadingButton component for easy use in forms and actions
interface LoadingButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  isLoading?: boolean;
  loadingText?: string;
  spinnerVariant?: 'ethereum' | 'chain' | 'blocks' | 'nodes';
  children: React.ReactNode;
}

export function LoadingButton({ 
  isLoading = false, 
  loadingText, 
  spinnerVariant = 'ethereum',
  children,
  disabled,
  className = '',
  ...props 
}: LoadingButtonProps) {
  return (
    <button
      disabled={isLoading || disabled}
      className={`relative px-4 py-2 rounded-lg font-medium transition-all flex items-center justify-center ${className}`}
      {...props}
    >
      {isLoading ? (
        <LoadingState 
          type="button" 
          text={loadingText} 
          variant={spinnerVariant} 
        />
      ) : children}
    </button>
  );
}

// LoadingContainer component that wraps content with a loading overlay
interface LoadingContainerProps {
  isLoading: boolean;
  loadingText?: string;
  spinnerVariant?: 'ethereum' | 'chain' | 'blocks' | 'nodes';
  spinnerSize?: 'sm' | 'md' | 'lg' | 'xl';
  children: React.ReactNode;
  className?: string;
}

export function LoadingContainer({ 
  isLoading, 
  loadingText, 
  spinnerVariant = 'ethereum',
  spinnerSize = 'md',
  children,
  className = ''
}: LoadingContainerProps) {
  return (
    <div className={`relative ${className}`}>
      {children}
      
      {isLoading && (
        <LoadingState 
          type="overlay" 
          text={loadingText} 
          variant={spinnerVariant}
          size={spinnerSize}
        />
      )}
    </div>
  );
}