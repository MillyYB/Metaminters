import { FaCheckCircle, FaEthereum } from "react-icons/fa";
import { SiFantom } from "react-icons/si";
import { cn } from "@/lib/utils";
import { useState } from "react";
import { Badge } from "@/components/ui/badge";

interface VerificationBadgeProps {
  className?: string;
}

export function VerificationBadge({ className }: VerificationBadgeProps) {
  const [showDetails, setShowDetails] = useState(false);
  
  return (
    <div className={cn("relative", className)}>
      <div 
        className="flex items-center gap-2 cursor-pointer border border-red-700 bg-gray-900 rounded-lg p-3 transition-all hover:bg-gray-800"
        onClick={() => setShowDetails(!showDetails)}
      >
        <div className="flex items-center text-green-500">
          <FaCheckCircle className="mr-1" size={16} />
          <span className="text-sm font-medium">Verified Site</span>
        </div>
        <Badge variant="outline" className="border-green-500 text-green-500 text-xs">
          Secure
        </Badge>
      </div>
      
      {showDetails && (
        <div className="absolute top-full left-0 mt-2 p-4 bg-black border border-red-700 rounded-lg shadow-xl z-50 w-72 animate-fade-in">
          <div className="mb-4">
            <h3 className="text-white font-bold text-lg mb-1">Site Verification</h3>
            <p className="text-gray-400 text-sm mb-3">
              MetaMinter has been verified as a legitimate NFT minting platform
            </p>
            <div className="bg-gray-900 rounded p-2 my-2">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <FaEthereum className="text-orange-500 mr-2" size={20} />
                  <span className="text-white font-medium">MetaMask</span>
                </div>
                <Badge className="bg-green-600">Verified</Badge>
              </div>
              <p className="text-gray-400 text-xs">
                Contract verified on March 15, 2025
              </p>
            </div>
            <div className="bg-gray-900 rounded p-2 my-2">
              <div className="flex justify-between items-center mb-2">
                <div className="flex items-center">
                  <SiFantom className="text-purple-400 mr-2" size={20} />
                  <span className="text-white font-medium">Phantom</span>
                </div>
                <Badge className="bg-green-600">Verified</Badge>
              </div>
              <p className="text-gray-400 text-xs">
                Partnership verified on February 22, 2025
              </p>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-3">
            <p className="text-gray-400 text-xs">
              All transactions on this site are secured with blockchain verification. 
              Payments are sent directly to the creator's verified wallet.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}

// Add animation keyframes for fading in
const style = document.createElement('style');
style.textContent = `
  @keyframes fadeIn {
    from { opacity: 0; transform: translateY(-10px); }
    to { opacity: 1; transform: translateY(0); }
  }
  
  .animate-fade-in {
    animation: fadeIn 0.3s ease-out forwards;
  }
`;
document.head.appendChild(style);