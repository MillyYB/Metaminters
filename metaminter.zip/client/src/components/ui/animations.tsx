import { useEffect } from 'react';

// Add global animations to the website
export function GlobalAnimations() {
  useEffect(() => {
    const style = document.createElement('style');
    style.textContent = `
      @keyframes float {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-10px); }
      }
      
      .animate-float {
        animation: float 3s ease-in-out infinite;
      }
      
      @keyframes pulse-border {
        0%, 100% { border-color: rgba(220, 38, 38, 0.3); }
        50% { border-color: rgba(220, 38, 38, 0.8); }
      }
      
      .animate-pulse-border {
        animation: pulse-border 2s infinite;
      }
      
      @keyframes bg-shine {
        0% { background-position: 200% center; }
        100% { background-position: -200% center; }
      }
      
      .animate-bg-shine {
        background: linear-gradient(90deg, #000 0%, #222 25%, #333 50%, #222 75%, #000 100%);
        background-size: 200% auto;
        animation: bg-shine 4s linear infinite;
      }
      
      @keyframes glow {
        0%, 100% { text-shadow: 0 0 5px rgba(220, 38, 38, 0.7), 0 0 10px rgba(220, 38, 38, 0.5); }
        50% { text-shadow: 0 0 20px rgba(220, 38, 38, 0.9), 0 0 30px rgba(220, 38, 38, 0.7); }
      }
      
      .text-glow {
        animation: glow 2s ease-in-out infinite;
      }
      
      @keyframes rotate-slow {
        from { transform: rotate(0deg); }
        to { transform: rotate(360deg); }
      }
      
      .animate-rotate-slow {
        animation: rotate-slow 20s linear infinite;
      }
      
      @keyframes bounce-subtle {
        0%, 100% { transform: translateY(0); }
        50% { transform: translateY(-5px); }
      }
      
      .animate-bounce-subtle {
        animation: bounce-subtle 2s ease-in-out infinite;
      }
      
      @keyframes shimmer {
        0% { background-position: -1000px 0; }
        100% { background-position: 1000px 0; }
      }
      
      .animate-shimmer {
        background: linear-gradient(90deg, transparent, rgba(220, 38, 38, 0.2), transparent);
        background-size: 1000px 100%;
        animation: shimmer 2s infinite;
      }
      
      @keyframes fade-in-staggered {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
      }
      
      .staggered-item {
        opacity: 0;
        animation: fade-in-staggered 0.5s ease forwards;
      }
      
      .staggered-container > *:nth-child(1) { animation-delay: 0.1s; }
      .staggered-container > *:nth-child(2) { animation-delay: 0.2s; }
      .staggered-container > *:nth-child(3) { animation-delay: 0.3s; }
      .staggered-container > *:nth-child(4) { animation-delay: 0.4s; }
      .staggered-container > *:nth-child(5) { animation-delay: 0.5s; }
      .staggered-container > *:nth-child(6) { animation-delay: 0.6s; }
      .staggered-container > *:nth-child(7) { animation-delay: 0.7s; }
      .staggered-container > *:nth-child(8) { animation-delay: 0.8s; }
    `;
    document.head.appendChild(style);
    
    return () => {
      document.head.removeChild(style);
    };
  }, []);
  
  return null;
}