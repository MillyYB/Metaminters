import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { IconType } from 'react-icons';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: IconType;
  change?: {
    value: number;
    isPositive: boolean;
  };
  progress?: number;
  className?: string;
}

export function StatsCard({ title, value, icon: Icon, change, progress, className }: StatsCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className={className}
    >
      <Card className="h-full">
        <CardContent className="pt-6">
          <div className="flex items-center">
            <div className="rounded-full bg-primary-100 p-3 mr-4">
              <Icon className="text-primary text-xl" />
            </div>
            <div>
              <p className="text-gray-500 text-sm">{title}</p>
              <h3 className="text-2xl font-bold">{value}</h3>
            </div>
          </div>
          
          {(change || progress !== undefined) && (
            <div className="mt-4">
              {change && (
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-500">Last 30 days</span>
                  <span className={cn(
                    "text-sm flex items-center",
                    change.isPositive ? "text-green-600" : "text-red-600"
                  )}>
                    <svg 
                      xmlns="http://www.w3.org/2000/svg" 
                      className="h-4 w-4 mr-1" 
                      fill="none" 
                      viewBox="0 0 24 24" 
                      stroke="currentColor"
                    >
                      {change.isPositive ? (
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                      ) : (
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                      )}
                    </svg>
                    {Math.abs(change.value)}%
                  </span>
                </div>
              )}
              
              {progress !== undefined && (
                <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                  <div 
                    className="bg-primary h-2 rounded-full" 
                    style={{ width: `${Math.min(100, Math.max(0, progress))}%` }}
                  />
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  );
}
